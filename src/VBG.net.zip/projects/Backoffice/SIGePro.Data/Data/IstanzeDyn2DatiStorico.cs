
using Init.SIGePro.DatiDinamici.Interfaces.Istanze;

namespace Init.SIGePro.Data
{
	public partial class IstanzeDyn2DatiStorico : IIstanzeDyn2DatiStorico
    {
	
	}
}
				