using System;
using System.Collections.Generic;
using System.Text;

namespace Init.SIGePro.Data
{
    public partial class IstanzeCalcoloCanoniT
    {


        public override string ToString()
        {
            return Descrizione;
        }
    }
}
