using System;
using System.Data;
using PersonalLib2.Sql.Attributes;

namespace Init.SIGePro.Data
{
	//[DataTable("PERMCDSISTANZE")]
	public partial class PermCdsIstanze : BaseDataClass
	{
        /*
		string idcomune=null;
		[KeyField("IDCOMUNE",Size=6, Type=DbType.String )]
		public string IDCOMUNE
		{
			get { return idcomune; }
			set { idcomune = value; }
		}

		string codicecds=null;
		[KeyField("CODICECDS", Type=DbType.Decimal)]
		public string CODICECDS
		{
			get { return codicecds; }
			set { codicecds = value; }
		}

		string codiceatto=null;
		[KeyField("CODICEATTO", Type=DbType.Decimal)]
		public string CODICEATTO
		{
			get { return codiceatto; }
			set { codiceatto = value; }
		}

		string codiceistanza=null;
		[KeyField("CODICEISTANZA", Type=DbType.Decimal)]
		public string CODICEISTANZA
		{
			get { return codiceistanza; }
			set { codiceistanza = value; }
		}
        */
	}
}