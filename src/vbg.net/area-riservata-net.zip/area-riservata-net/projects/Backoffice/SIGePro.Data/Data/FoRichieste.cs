
using System;
using System.Collections.Generic;
using System.Text;
using Init.SIGePro.Attributes;
using PersonalLib2.Sql.Attributes;
using System.Data;

namespace Init.SIGePro.Data
{
    public partial class FoRichieste
    {
		public const int RICHIESTA_MODIFICA_DATI = 1;
		public const int RICHIESTA_NUOVA_REGISTRAZIONE = 2;
	}
}
				