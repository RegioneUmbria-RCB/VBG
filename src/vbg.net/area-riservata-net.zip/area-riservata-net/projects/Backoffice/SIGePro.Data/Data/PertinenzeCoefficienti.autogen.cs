
using System;
using System.Data;
using System.Reflection;
using System.Text;
using Init.SIGePro.Attributes;

using PersonalLib2.Sql.Attributes;
using PersonalLib2.Sql;

namespace Init.SIGePro.Data
{
    ///
    /// File generato automaticamente dalla tabella PERTINENZE_COEFFICIENTI il 11/11/2008 9.20.11
    ///
    ///												ATTENZIONE!!!
    ///	- Specificare manualmente in quali colonne vanno applicate eventuali sequenze		
    /// - Verificare l'applicazione di eventuali attributi di tipo "[isRequired]". In caso contrario applicarli manualmente
    ///	- Verificare che il tipo di dati assegnato alle proprietà sia corretto
    ///
    ///						ELENCARE DI SEGUITO EVENTUALI MODIFICHE APPORTATE MANUALMENTE ALLA CLASSE
    ///				(per tenere traccia dei cambiamenti nel caso in cui la classe debba essere generata di nuovo)
    /// -
    /// -
    /// -
    /// - 
    ///
    ///	Prima di effettuare modifiche al template di MyGeneration in caso di dubbi contattare Nicola Gargagli ;)
    ///
    [DataTable("PERTINENZE_COEFFICIENTI")]
    [Serializable]
    public partial class PertinenzeCoefficienti : BaseDataClass
    {
        #region Membri privati

        private string m_idcomune = null;

        private int? m_id = null;

        private int? m_anno = null;

        private int? m_fk_crid = null;

        private int? m_fk_ccid = null;

        private int? m_fk_tsid = null;

        private double? m_perc_riduzione = null;

        #endregion

        #region properties

        #region Key Fields


        [KeyField("IDCOMUNE", Type = DbType.String, Size = 6)]
        public string Idcomune
        {
            get { return m_idcomune; }
            set { m_idcomune = value; }
        }
        #endregion

        #region Data fields

        [isRequired]
        [DataField("ANNO", Type = DbType.Decimal)]
        public int? Anno
        {
            get { return m_anno; }
            set { m_anno = value; }
        }

        [isRequired]
        [DataField("FK_CRID", Type = DbType.Decimal)]
        public int? FkCrid
        {
            get { return m_fk_crid; }
            set { m_fk_crid = value; }
        }
        
        [isRequired]
        [DataField("FK_CCID", Type = DbType.Decimal)]
        public int? FkCcid
        {
            get { return m_fk_ccid; }
            set { m_fk_ccid = value; }
        }

        [isRequired]
        [DataField("FK_TSID", Type = DbType.Decimal)]
        public int? FkTsid
        {
            get { return m_fk_tsid; }
            set { m_fk_tsid = value; }
        }

        [DataField("PERC_RIDUZIONE", Type = DbType.Decimal)]
        public double? PercRiduzione
        {
            get { return m_perc_riduzione; }
            set { m_perc_riduzione = value; }
        }

        #endregion

        #endregion
    }
}
