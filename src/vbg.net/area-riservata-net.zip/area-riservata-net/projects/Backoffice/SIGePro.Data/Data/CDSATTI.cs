using System;
using System.Data;
using PersonalLib2.Sql.Attributes;

namespace Init.SIGePro.Data
{
	public partial class CdsAtti : BaseDataClass
	{

	}
}