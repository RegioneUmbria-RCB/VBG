
using Init.SIGePro.DatiDinamici.Interfaces;

namespace Init.SIGePro.Data
{
    public partial class IstanzeDyn2DatiStorico : IValoreCampo
    {
        public string Valoredecodificato => Valore;
    }
}
