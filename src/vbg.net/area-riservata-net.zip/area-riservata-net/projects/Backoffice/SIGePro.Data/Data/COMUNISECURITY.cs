//
//using PersonalLib2.Sql.Attributes;
//using System;
//using System.Collections.Generic;
//using System.Data;

//namespace Init.SIGePro.Data
//{
//    [DataTable("COMUNISECURITY")]
//    [Serializable]
//    public class ComuniSecurity : BaseDataClass
//    {
//        private string cs_codiceistat = null;
//        [KeyField("CS_CODICEISTAT", Size = 20, Type = DbType.String, CaseSensitive = false)]
//        public string CS_CODICEISTAT
//        {
//            get { return this.cs_codiceistat; }
//            set { this.cs_codiceistat = value; }
//        }

//        private string cs_dbuser = null;
//        [DataField("CS_DBUSER", Size = 25, Type = DbType.String, Compare = "like", CaseSensitive = false)]
//        public string CS_DBUSER
//        {
//            get { return this.cs_dbuser; }
//            set { this.cs_dbuser = value; }
//        }

//        private string cs_dbpwd = null;
//        [DataField("CS_DBPWD", Size = 25, Type = DbType.String, Compare = "like", CaseSensitive = false)]
//        public string CS_DBPWD
//        {
//            get { return this.cs_dbpwd; }
//            set { this.cs_dbpwd = value; }
//        }

//        private string cs_connectionstring = null;
//        [DataField("CS_CONNECTIONSTRING", Size = 150, Type = DbType.String, Compare = "like", CaseSensitive = false)]
//        public string CS_CONNECTIONSTRING
//        {
//            get { return this.cs_connectionstring; }
//            set { this.cs_connectionstring = value; }
//        }

//        private string cs_attivo = null;
//        [DataField("CS_ATTIVO", Type = DbType.Decimal)]
//        public string CS_ATTIVO
//        {
//            get { return this.cs_attivo; }
//            set { this.cs_attivo = value; }
//        }

//        private string cs_crdsn = null;
//        [DataField("CS_CRDSN", Size = 20, Type = DbType.String, CaseSensitive = false)]
//        public string CS_CRDSN
//        {
//            get { return this.cs_crdsn; }
//            set { this.cs_crdsn = value; }
//        }

//        private string cs_owner = null;
//        [DataField("CS_OWNER", Size = 25, Type = DbType.String, Compare = "like", CaseSensitive = false)]
//        public string CS_OWNER
//        {
//            get { return this.cs_owner; }
//            set { this.cs_owner = value; }
//        }

//        private string cs_softwareattivi = null;
//        [DataField("CS_SOFTWAREATTIVI", Size = 50, Type = DbType.String, Compare = "like", CaseSensitive = false)]
//        public string CS_SOFTWAREATTIVI
//        {
//            get { return this.cs_softwareattivi; }
//            set { this.cs_softwareattivi = value; }
//        }

//        private string cs_ogg_terr = null;
//        [DataField("CS_OGG_TERR", Type = DbType.Decimal)]
//        public string CS_OGG_TERR
//        {
//            get { return this.cs_ogg_terr; }
//            set { this.cs_ogg_terr = value; }
//        }

//        private string cs_showreport = null;
//        [DataField("CS_SHOWREPORT", Size = 5, Type = DbType.String, CaseSensitive = false)]
//        public string CS_SHOWREPORT
//        {
//            get { return this.cs_showreport; }
//            set { this.cs_showreport = value; }
//        }

//        private string cs_idcomune = null;
//        [DataField("CS_IDCOMUNE", Size = 6, Type = DbType.String, CaseSensitive = false)]
//        public string CS_IDCOMUNE
//        {
//            get
//            {
//                return this.cs_idcomune;
//            }
//            set { this.cs_idcomune = value; }
//        }

//        private string cs_softwareattivifo = null;
//        [DataField("CS_SOFTWAREATTIVIFO", Size = 50, Type = DbType.String, Compare = "like", CaseSensitive = false)]
//        public string CS_SOFTWAREATTIVIFO
//        {
//            get { return this.cs_softwareattivifo; }
//            set { this.cs_softwareattivifo = value; }
//        }

//        private string cs_dbaggiornato = null;
//        [DataField("CS_DBAGGIORNATO", Size = 1, Type = DbType.String, CaseSensitive = false)]
//        public string CS_DBAGGIORNATO
//        {
//            get { return this.cs_dbaggiornato; }
//            set { this.cs_dbaggiornato = value; }
//        }

//        private CSConnectionStringCollection _CSConnectionStringColl = new CSConnectionStringCollection();
//        public CSConnectionStringCollection CSConnectionStringColl
//        {
//            get { return this._CSConnectionStringColl; }
//            set { this._CSConnectionStringColl = value; }
//        }
//        public List<string> CSProviderColl { get; set; } = new List<string>();

//        private CSAmbienteCollection _CSAmbienteColl = new CSAmbienteCollection();
//        public CSAmbienteCollection CSAmbienteColl
//        {
//            get { return this._CSAmbienteColl; }
//            set { this._CSAmbienteColl = value; }
//        }


//        public string GetIdComune()
//        {
//            if (String.IsNullOrEmpty(this.CS_IDCOMUNE))
//                return this.CS_CODICEISTAT;

//            return this.CS_IDCOMUNE;
//        }

//    }
//}