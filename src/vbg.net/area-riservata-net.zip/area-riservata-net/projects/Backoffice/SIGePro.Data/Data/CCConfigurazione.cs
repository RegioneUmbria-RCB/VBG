using System;
using System.Collections.Generic;
using System.Text;

namespace Init.SIGePro.Data
{
	public partial class CCConfigurazione
	{
		public const int CALCSUP_DETTAGLIUI = 0;
		public const int CALCSUP_MODELLO = 2;
	}
}
