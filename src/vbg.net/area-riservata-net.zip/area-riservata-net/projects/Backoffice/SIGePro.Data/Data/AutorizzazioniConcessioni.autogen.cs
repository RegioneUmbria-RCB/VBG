﻿using Init.SIGePro.Attributes;
using Init.SIGePro.DatiDinamici.Interfaces;
using PersonalLib2.Sql.Attributes;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Init.SIGePro.Data
{
    [DataTable("AUTORIZZAZIONI_CONCESSIONI")]
    [Serializable]
    public partial class AutorizzazioniConcessioni : BaseDataClass, IClasseContestoModelloDinamico
    {
        #region Membri privati
        private DateTime? _datascadenza = null;
        #endregion

        #region properties

        #region Key Fields
        [KeyField("ID", Type = DbType.Decimal)]
        [useSequence]
        [XmlElement(Order = 10)]
        public int? Id { get; set; }

        [KeyField("IDCOMUNE", Type = DbType.String, Size = 6)]
        [XmlElement(Order = 20)]
        public string Idcomune { get; set; }

        [isRequired]
        [DataField("FK_CODICEMERCATO", Type = DbType.Decimal)]
        [XmlElement(Order = 30)]
        public int? FkCodiceMercato { get; set; }

        [isRequired]
        [DataField("FK_IDMERCATIUSO", Type = DbType.Decimal)]
        [XmlElement(Order = 40)]
        public int? FkIdMercatiUso { get; set; }

        [isRequired]
        [DataField("FK_IDPOSTEGGIO", Type = DbType.Decimal)]
        [XmlElement(Order = 50)]
        public int? FkIdPosteggio { get; set; }

        [isRequired]
        [DataField("FK_TIPOCONCESSIONE", Type = DbType.String, CaseSensitive = false, Size = 2)]
        [XmlElement(Order = 60)]
        public string FkTipoConcessione { get; set; }

        [DataField("STAGIONALEDA", Type = DbType.String, CaseSensitive = false, Size = 4)]
        [XmlElement(Order = 70)]
        public string StagionaleDa { get; set; }

        [DataField("STAGIONALEA", Type = DbType.String, CaseSensitive = false, Size = 4)]
        [XmlElement(Order = 80)]
        public string StagionaleA { get; set; }

        [DataField("DATASCADENZA", Type = DbType.DateTime)]
        [XmlElement(Order = 90)]
        public DateTime? DataScadenza
        {
            get { return this._datascadenza; }
            set { this._datascadenza = this.VerificaDataLocale(value); }
        }

        [isRequired]
        [DataField("FK_IDAUT_ATTUALE", Type = DbType.Decimal)]
        [XmlElement(Order = 100)]
        public int? FkIdAutAttuale { get; set; }

        [DataField("FK_IDAUT_COLLEGATA", Type = DbType.Decimal)]
        [XmlElement(Order = 110)]
        public int? FkIdAutCollegata { get; set; }

        [ForeignKey("Idcomune,FkIdPosteggio", "IdComune,IdPosteggio")]
        [XmlElement(Order = 14)]
        public Mercati_D Posteggio { get; set; }

        #endregion
        #endregion
    }
}
