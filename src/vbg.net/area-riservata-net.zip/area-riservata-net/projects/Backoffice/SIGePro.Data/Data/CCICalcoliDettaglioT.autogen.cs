
using Init.SIGePro.Attributes;
using PersonalLib2.Sql.Attributes;
using System;
using System.Data;

namespace Init.SIGePro.Data
{
    ///
    /// File generato automaticamente dalla tabella CC_ICALCOLI_DETTAGLIOT il 30/06/2008 11.07.01
    ///
    ///												ATTENZIONE!!!
    ///	- Specificare manualmente in quali colonne vanno applicate eventuali sequenze		
    /// - Verificare l'applicazione di eventuali attributi di tipo "[isRequired]". In caso contrario applicarli manualmente
    ///	- Verificare che il tipo di dati assegnato alle proprietà sia corretto
    ///
    ///						ELENCARE DI SEGUITO EVENTUALI MODIFICHE APPORTATE MANUALMENTE ALLA CLASSE
    ///				(per tenere traccia dei cambiamenti nel caso in cui la classe debba essere generata di nuovo)
    /// -
    /// -
    /// -
    /// - 
    ///
    ///	Prima di effettuare modifiche al template di MyGeneration in caso di dubbi contattare Nicola Gargagli ;)
    ///
    [DataTable("CC_ICALCOLI_DETTAGLIOT")]
    [Serializable]
    public partial class CCICalcoliDettaglioT : BaseDataClass
    {
        #region Membri privati


        private string m_idcomune = null;

        private int? m_id = null;

        private int? m_codiceistanza = null;

        private int? m_ordine = null;

        private int? m_fk_ccts_id = null;

        private int? m_fk_ccds_id = null;

        private string m_descrizione = null;

        private double? m_su = null;

        private int? m_fk_ccic_id = null;

        private int? m_alloggi = null;

        #endregion

        #region properties



        #region Key Fields


        [KeyField("IDCOMUNE", Type = DbType.String, CaseSensitive = true, Size = 6)]
        public string Idcomune
        {
            get { return this.m_idcomune; }
            set { this.m_idcomune = value; }
        }

        [KeyField("ID", Type = DbType.Decimal)]
        [useSequence]
        public int? Id
        {
            get { return this.m_id; }
            set { this.m_id = value; }
        }


        #endregion

        #region Data fields

        [isRequired]
        [DataField("CODICEISTANZA", Type = DbType.Decimal)]
        public int? Codiceistanza
        {
            get { return this.m_codiceistanza; }
            set { this.m_codiceistanza = value; }
        }

        [isRequired]
        [DataField("ORDINE", Type = DbType.Decimal)]
        public int? Ordine
        {
            get { return this.m_ordine; }
            set { this.m_ordine = value; }
        }

        [isRequired]
        [DataField("FK_CCTS_ID", Type = DbType.Decimal)]
        public int? FkCctsId
        {
            get { return this.m_fk_ccts_id; }
            set { this.m_fk_ccts_id = value; }
        }

        [DataField("FK_CCDS_ID", Type = DbType.Decimal)]
        public int? FkCcdsId
        {
            get { return this.m_fk_ccds_id; }
            set { this.m_fk_ccds_id = value; }
        }

        [DataField("DESCRIZIONE", Type = DbType.String, CaseSensitive = false, Size = 200)]
        public string Descrizione
        {
            get { return this.m_descrizione; }
            set { this.m_descrizione = value; }
        }

        [isRequired]
        [DataField("SU", Type = DbType.Decimal)]
        public double? Su
        {
            get { return this.m_su; }
            set { this.m_su = value; }
        }

        [isRequired]
        [DataField("FK_CCIC_ID", Type = DbType.Decimal)]
        public int? FkCcicId
        {
            get { return this.m_fk_ccic_id; }
            set { this.m_fk_ccic_id = value; }
        }

        [isRequired]
        [DataField("ALLOGGI", Type = DbType.Decimal)]
        public int? Alloggi
        {
            get { return this.m_alloggi; }
            set { this.m_alloggi = value; }
        }

        #endregion

        #endregion
    }
}
