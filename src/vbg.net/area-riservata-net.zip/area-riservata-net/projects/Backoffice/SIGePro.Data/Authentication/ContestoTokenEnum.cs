﻿// -----------------------------------------------------------------------
// <copyright file="ContestoType.cs" company="">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace Init.SIGePro.Authentication
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;

	public enum ContestoTokenEnum
	{
		Amministratore,
		Applicazione,
		Operatore,
		Utente
	}
}
