//using System.Collections.Generic;

//namespace Init.SIGePro.Authentication
//{
//    /// <summary>
//    /// Descrizione di riepilogo per CSecurityList.
//    /// </summary>
//    //Non utilizzata
//    public class CSecurityList
//    {
//        public CSecurityList()
//        {
//        }

//        private List<SecurityInfo> _List = new List<SecurityInfo>();
//        public List<SecurityInfo> SecurityInfoList
//        {
//            get { return this._List; }
//            set { this._List = value; }
//        }
//    }
//}
