using System;
using System.Data;
using PersonalLib2.Sql.Attributes;

namespace Init.SIGePro.Data
{
	//[DataTable("CDSCONVOCAZIONI")]
	public partial class CdsConvocazioni : BaseDataClass
	{   
	}
}