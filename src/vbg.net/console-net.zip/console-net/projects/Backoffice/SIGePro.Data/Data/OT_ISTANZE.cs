using System;
using System.Data;
using PersonalLib2.Sql.Attributes;

namespace Init.SIGePro.Data
{
	//[DataTable("OT_ISTANZE")]
	public partial class Ot_Istanze : BaseDataClass
	{
        /*
		string idcomune=null;
		[KeyField("IDCOMUNE",Size=6, Type=DbType.String )]
		public string IDCOMUNE
		{
			get { return idcomune; }
			set { idcomune = value; }
		}

		string codiceistanza=null;
		[KeyField("CODICEISTANZA", Type=DbType.Decimal)]
		public string CODICEISTANZA
		{
			get { return codiceistanza; }
			set { codiceistanza = value; }
		}

		string codvia=null;
		[DataField("CODVIA", Type=DbType.Decimal)]
		public string CODVIA
		{
			get { return codvia; }
			set { codvia = value; }
		}

		string descvia=null;
		[DataField("DESCVIA",Size=128, Type=DbType.String, Compare="like", CaseSensitive=false)]
		public string DESCVIA
		{
			get { return descvia; }
			set { descvia = value; }
		}

		string civico=null;
		[DataField("CIVICO",Size=25, Type=DbType.String, Compare="like", CaseSensitive=false)]
		public string CIVICO
		{
			get { return civico; }
			set { civico = value; }
		}

		string bis=null;
		[DataField("BIS",Size=3, Type=DbType.String, CaseSensitive=false)]
		public string BIS
		{
			get { return bis; }
			set { bis = value; }
		}

		string foglio=null;
		[DataField("FOGLIO",Size=50, Type=DbType.String, Compare="like", CaseSensitive=false)]
		public string FOGLIO
		{
			get { return foglio; }
			set { foglio = value; }
		}

		string numero=null;
		[DataField("NUMERO",Size=50, Type=DbType.String, Compare="like", CaseSensitive=false)]
		public string NUMERO
		{
			get { return numero; }
			set { numero = value; }
		}

		string subalterno=null;
		[DataField("SUBALTERNO",Size=50, Type=DbType.String, Compare="like", CaseSensitive=false)]
		public string SUBALTERNO
		{
			get { return subalterno; }
			set { subalterno = value; }
		}

		string interno=null;
		[DataField("INTERNO",Size=3, Type=DbType.String, CaseSensitive=false)]
		public string INTERNO
		{
			get { return interno; }
			set { interno = value; }
		}

		string piano=null;
		[DataField("PIANO",Size=4, Type=DbType.String, CaseSensitive=false)]
		public string PIANO
		{
			get { return piano; }
			set { piano = value; }
		}

		string scala=null;
		[DataField("SCALA",Size=2, Type=DbType.String, CaseSensitive=false)]
		public string SCALA
		{
			get { return scala; }
			set { scala = value; }
		}

		string ot_fabb_numogg=null;
		[DataField("OT_FABB_NUMOGG",Size=6, Type=DbType.String, CaseSensitive=false)]
		public string OT_FABB_NUMOGG
		{
			get { return ot_fabb_numogg; }
			set { ot_fabb_numogg = value; }
		}

		string ot_oggc_numogg=null;
		[DataField("OT_OGGC_NUMOGG",Size=9, Type=DbType.String, CaseSensitive=false)]
		public string OT_OGGC_NUMOGG
		{
			get { return ot_oggc_numogg; }
			set { ot_oggc_numogg = value; }
		}
        */
	}
}