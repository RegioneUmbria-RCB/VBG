using System;
using System.Data;
using PersonalLib2.Sql.Attributes;

namespace Init.SIGePro.Data
{
	//[DataTable("CDSINVITATI2")]
	public partial class CdsInvitati2 : BaseDataClass
	{
        /*
		string idcomune=null;
		[KeyField("IDCOMUNE",Size=6, Type=DbType.String )]
		public string IDCOMUNE
		{
			get { return idcomune; }
			set { idcomune = value; }
		}

		string fkidtestata=null;
		[KeyField("FKIDTESTATA", Type=DbType.Decimal)]
		public string FKIDTESTATA
		{
			get { return fkidtestata; }
			set { fkidtestata = value; }
		}

		string codiceinvitato=null;
		[KeyField("CODICEINVITATO", Type=DbType.Decimal)]
		public string CODICEINVITATO
		{
			get { return codiceinvitato; }
			set { codiceinvitato = value; }
		}

		string codiceistanza=null;
		[KeyField("CODICEISTANZA", Type=DbType.Decimal)]
		public string CODICEISTANZA
		{
			get { return codiceistanza; }
			set { codiceistanza = value; }
		}

		string codiceatto=null;
		[DataField("CODICEATTO", Type=DbType.Decimal)]
		public string CODICEATTO
		{
			get { return codiceatto; }
			set { codiceatto = value; }
		}

		string codiceanagrafe=null;
		[DataField("CODICEANAGRAFE", Type=DbType.Decimal)]
		public string CODICEANAGRAFE
		{
			get { return codiceanagrafe; }
			set { codiceanagrafe = value; }
		}

		string note=null;
		[DataField("NOTE",Size=255, Type=DbType.String, Compare="like", CaseSensitive=false)]
		public string NOTE
		{
			get { return note; }
			set { note = value; }
		}
         */
	}
}