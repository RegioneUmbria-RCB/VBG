using System;
using System.Collections.Generic;
using System.Text;
using PersonalLib2.Sql.Attributes;
using System.Data;


namespace Init.SIGePro.Data
{
	public partial class MappaturePeopleT : BaseDataClass
	{

	}
}
