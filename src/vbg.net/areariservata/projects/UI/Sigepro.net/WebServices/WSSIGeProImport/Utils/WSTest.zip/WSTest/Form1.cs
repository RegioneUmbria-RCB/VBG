using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using MSXML2;

namespace WSTest
{
	/// <summary>
	/// Descrizione di riepilogo per Form1.
	/// </summary>
	public class Form1 : Form
	{
		private Label label1;
		private Button button1;
		private TextBox textBox1;
		private OpenFileDialog openFileDialog1;
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private Container components = null;

		public Form1()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new Label();
			this.button1 = new Button();
			this.textBox1 = new TextBox();
			this.openFileDialog1 = new OpenFileDialog();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new Point(5, 10);
			this.label1.Name = "label1";
			this.label1.Size = new Size(100, 20);
			this.label1.TabIndex = 0;
			this.label1.Text = "File Datidoc.XML";
			// 
			// button1
			// 
			this.button1.Location = new Point(105, 5);
			this.button1.Name = "button1";
			this.button1.Size = new Size(35, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "...";
			this.button1.Click += new EventHandler(this.button1_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new Point(145, 5);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new Size(445, 20);
			this.textBox1.TabIndex = 2;
			this.textBox1.Text = "";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new Size(5, 13);
			this.ClientSize = new Size(597, 188);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Il punto di ingresso principale dell'applicazione.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, EventArgs e)
		{
			openFileDialog1.Filter = "XML documents (*.xml)|*.xml";
			openFileDialog1.ShowDialog();

			if ( openFileDialog1.FileName.Length > 0 )
			{
				TextReader tr = File.OpenText(openFileDialog1.FileName);
				InvocaWS( tr.ReadToEnd() );
		
				tr.Close();
			}
		}

		private void InvocaWS( string CorpoXml )
		{
			XMLHTTP30 http = new XMLHTTP30();
			string ServiceUrl = "http://localhost/WSSIGePro/DocArea.asmx";
			object missing  = Missing.Value;
			string msg = "<soap:Envelope " +
							"xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' " +
							"xmlns:xsd='http://www.w3.org/2001/XMLSchema' " +
							"xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'>" +
							"<soap:Body>" +
							"<InserisciIstanza xmlns='http://tempuri.org/'>" +
							CorpoXml +
							"</InserisciIstanza>" +
							"</soap:Body>" + 
							"</soap:Envelope>";

			http.open( "POST", ServiceUrl, false, missing, missing );
			http.setRequestHeader("SOAPAction","\"http://tempuri.org/InserisciIstanza\"");
			http.setRequestHeader("Content-Type","text/xml");
			http.send(msg);

			MessageBox.Show( http.responseText );
		}

		private void Form1_Load(object sender, EventArgs e)
		{
		
		}
	}
}
