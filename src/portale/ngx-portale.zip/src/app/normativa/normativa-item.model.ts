export class NormativaItemModel {
    titolo: string;
    descrizione: string;
    codiceOggetto?: string;
    url?: string;
}
