export class ProcedimentoDetailModel {

}
