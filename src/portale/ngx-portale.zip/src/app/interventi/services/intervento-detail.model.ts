export class InterventoDetailModel {

}
