export class InterventoCercato {
    id: string;
    text: string;
    hasChilds: boolean;
}
