export class InterventoModel {}
