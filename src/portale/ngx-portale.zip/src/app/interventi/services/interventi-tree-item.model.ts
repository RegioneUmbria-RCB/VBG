export class InterventiTreeItemModel {
    hasChilds: boolean;
    id: string;
    text: string;
}
