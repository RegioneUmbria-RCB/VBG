export class InterventoTopModel {
    id: number;
    descrizioneEstesa: string;
    descrizione: string;
}
