import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';


import { ServiceResponse } from '../../core/models';
import { InterventoTopModel } from './intervento-top.model';
import { InterventoCercato } from './intervento-cercato.model';
import { InterventiTreeItemModel } from './interventi-tree-item.model';
import { InterventoDetailModel } from './intervento-detail.model';
import { BaseUrlservice } from '../../core';

@Injectable()
export class InterventiBaseService {

  interventiTop: InterventoTopModel[] = null;

  constructor(private urlService: BaseUrlservice, private http: HttpClient) { }

  getTop(): Observable<InterventoTopModel[]> {

    const url = this.urlService.url('interventi', ['top']);

    if (this.interventiTop !== null) {
      return Observable.from([this.interventiTop]);
    }

    return this.http.get<ServiceResponse<InterventoTopModel[]>>(url).map(x => x.items);
  }

  cerca(testo: string): Observable<InterventoCercato[]> {
    const url = this.urlService.url('interventi', ['cerca', encodeURIComponent(testo).replace('.', '%2E')]);

    return this.http.get<ServiceResponse<InterventoCercato[]>>(url)
      .map(x => x.items)
      .catch(res => Observable.of([]));

  }

  getSottonodi(idNodo: string): Observable<InterventiTreeItemModel[]> {

    const url = this.urlService.url('interventi', ['sottonodi', idNodo]);

    return this.http.get<ServiceResponse<InterventiTreeItemModel[]>>(url)
      .map(x => x.items);
  }


  getGerarchia(idNodo: string) {
    const url = this.urlService.url('interventi', ['gerarchia', idNodo]);

    return this.http.get<ServiceResponse<string[]>>(url)
      .map(x => x.items);
  }

  getTreeItemById(idNodo: string): Observable<InterventiTreeItemModel> {
    const url = this.urlService.url('interventi', [idNodo]);

    if (idNodo === '-1') {
      return Observable.of(new InterventiTreeItemModel());
    }
    return this.http.get<ServiceResponse<any>>(url)
      .map(x => {
        const item = new InterventiTreeItemModel();

        item.id = x.items.id;
        item.text = x.items.nome;
        item.hasChilds = true;

        return item;
      });
  }

  getById(id: string): Observable<InterventoDetailModel> {
    const url = this.urlService.url('interventi', [id]);

    return this.http.get<ServiceResponse<InterventoDetailModel>>(url)
      .map(x => x.items);
  }

  urlDownload(id: string) {

  }
}
