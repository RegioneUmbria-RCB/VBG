import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RicercaInterventiComponent } from './ricerca-interventi.component';

describe('RicercaInterventiComponent', () => {
  let component: RicercaInterventiComponent;
  let fixture: ComponentFixture<RicercaInterventiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RicercaInterventiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RicercaInterventiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
