import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/zip';

import { UrlLocaliService } from '../../core/services/url';
import { InterventiLocaliService, InterventiTreeItemModel } from '../services';
import { InterventiTreeNavigatorComponent } from '../interventi-tree-navigator/interventi-tree-navigator.component';

@Component({
  selector: 'app-interventi-locali',
  templateUrl: './interventi-locali.component.html',
  styleUrls: ['./interventi-locali.component.less']
})
export class InterventiLocaliComponent implements OnInit {

  caricamentoCompletato = true;

  @ViewChild(InterventiTreeNavigatorComponent) treeNavigator: InterventiTreeNavigatorComponent;

  constructor(private service: InterventiLocaliService, private router: Router,
    private route: ActivatedRoute, private urlLocaliService: UrlLocaliService) { }

  ngOnInit() {

    this.treeNavigator.service = this.service;

    this.route.queryParams
      .map(params => params['open'])
      .filter(val => val)
      .subscribe(open => this.treeNavigator.ripristinaGerarchia(open));

    this.treeNavigator.ripristinaGerarchia('-1');
  }

  statoCaricamento(val: boolean) {
    this.caricamentoCompletato = val;
  }


  onFogliaSelezionata($event: any) {
    console.log($event);

    const url = this.urlLocaliService.url('/interventi-locali', [$event.node.id]);

    this.router.navigate([url], {
      queryParams: {
        returnTo: $event.lastNode.id
      }
    });

  }
}
