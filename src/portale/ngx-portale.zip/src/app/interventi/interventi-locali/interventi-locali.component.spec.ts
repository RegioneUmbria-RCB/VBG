import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterventiLocaliComponent } from './interventi-locali.component';

describe('InterventiLocaliComponent', () => {
  let component: InterventiLocaliComponent;
  let fixture: ComponentFixture<InterventiLocaliComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterventiLocaliComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterventiLocaliComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
