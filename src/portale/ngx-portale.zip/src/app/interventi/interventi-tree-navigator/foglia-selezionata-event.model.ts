import { InterventiTreeItemModel } from '../services';

export class FogliaSelezionataEventModel {
    constructor(public node: InterventiTreeItemModel, public lastNode: InterventiTreeItemModel) {
    }
}
