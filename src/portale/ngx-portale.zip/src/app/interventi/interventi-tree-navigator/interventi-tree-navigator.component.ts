import { Component, EventEmitter, OnInit, Input, Output } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/zip';

import { InterventiBaseService, InterventiTreeItemModel } from '../services';
import { FogliaSelezionataEventModel } from './foglia-selezionata-event.model';



@Component({
  selector: 'app-interventi-tree-navigator',
  templateUrl: './interventi-tree-navigator.component.html',
  styleUrls: ['./interventi-tree-navigator.component.less']
})
export class InterventiTreeNavigatorComponent implements OnInit {

  private _service: InterventiBaseService = null;
  private _idFogliaIniziale = '-1';

  @Output() fogliaSelezionata = new EventEmitter<FogliaSelezionataEventModel>();

  @Output() caricamentoIniziato = new EventEmitter<void>();
  @Output() caricamentoCompletato = new EventEmitter<void>();

  dataSource: InterventiTreeItemModel[] = [];

  get service(): InterventiBaseService {
    return this._service;
  }

  @Input()
  set service(val: InterventiBaseService) {
    this._service = val;
  }

  lastNode: InterventiTreeItemModel = null;


  constructor() { }

  ngOnInit() {
  }


  elementoSelezionato(nodo: InterventiTreeItemModel) {

    if (!nodo.hasChilds) {
      this.fogliaSelezionata.emit(new FogliaSelezionataEventModel(nodo, this.lastNode));
    } else {
      this.lastNode = nodo;
      this.caricaSottonodi(nodo.id);
    }
  }


  tornaIndietro(nodo: InterventiTreeItemModel) {

    this.caricamentoIniziato.emit();

    this.service
      .getGerarchia(nodo.id)
      .map(list => list.length > 1 ? list[list.length - 2] : '-1')
      .subscribe(idNodo => this.ripristinaGerarchia(idNodo));
  }

  ripristinaGerarchia(idNodo: string) {
    Observable.zip(
      this.service.getSottonodi(idNodo),
      this.service.getTreeItemById(idNodo),
      (...res) => {
        return {
          sottonodi: res[0],
          treeItem: res[1]
        };
      })
      .subscribe(res => {
        this.dataSource = res.sottonodi;
        this.lastNode = idNodo === '-1' ? null : res.treeItem;

        this.caricamentoCompletato.emit();
      }, err => console.error(err));
  }


  private caricaSottonodi(idNodo: string) {

    this.caricamentoIniziato.emit();

    return this.service.getSottonodi(idNodo).subscribe(data => {
      this.caricamentoCompletato.emit();

      this.dataSource = data;
    });
  }

}
