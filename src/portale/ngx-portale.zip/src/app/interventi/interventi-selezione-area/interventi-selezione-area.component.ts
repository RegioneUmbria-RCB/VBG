import { Component, OnInit } from '@angular/core';
import {ButtonGridItem} from '../../core/components';
import {UrlLocaliService} from '../../core/services';

@Component({
  selector: 'app-interventi-selezione-area',
  templateUrl: './interventi-selezione-area.component.html',
  styleUrls: ['./interventi-selezione-area.component.less']
})
export class InterventiSelezioneAreaComponent implements OnInit {

  scelte: ButtonGridItem[] = [];

  constructor(private urlService: UrlLocaliService) { }

  ngOnInit() {
    this.scelte = [
      {
        id: 'interventi-regionali',
        titolo: 'Attività commerciali e assimilate (d.lgs. 222/2016)',
        sottotitolo: 'Scegliere questa sezione per inviare pratiche relative ad' +
                    ' attività di commercio in sede fissa (esercizi di vicinato, ' +
                    ' media e grande strutture, forme speciali, ...) di somministrazione' +
                    ' alimenti e bevande (rif. artt. 42-42 bis-43 della LR 28/2005 e' +
                    ' anche art. 45 per la temporanea), di acconciatore e di estetica',
        link: this.urlService.url('/interventi-regionali')
      },
      {
        id: 'interventi-locali',
        titolo: 'Altre attività',
        sottotitolo: 'Scegliere questa sezione per inviare pratiche relative' +
                     ' alle altre attività per le quali non è ancora stata approvata una modulistica unificata',
        link: this.urlService.url('/interventi-locali')
      }
    ];
  }

}
