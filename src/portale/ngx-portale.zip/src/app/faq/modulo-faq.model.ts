import { FaqModel } from './faq.model';

export class ModuloFaqModel {
    id: string;
    descrizione: boolean;

    faq: FaqModel[];
}
