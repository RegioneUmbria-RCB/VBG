export class TopFaqModel {
    id: string;
    titolo: string;
    descrizioneCategoria: string;
}
