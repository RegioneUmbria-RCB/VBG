export class FaqModel {
    id: string;
    attiva: boolean;
    visibile: boolean;
}
