export class ModulisticaItemModel {
    codice: string;
    descrizione: string;
    titolo: string;
    fileId: string;
}
