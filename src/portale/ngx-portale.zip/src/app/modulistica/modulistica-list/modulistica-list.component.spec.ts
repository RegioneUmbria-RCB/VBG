import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModulisticaListComponent } from './modulistica-list.component';

describe('ModulisticaListComponent', () => {
  let component: ModulisticaListComponent;
  let fixture: ComponentFixture<ModulisticaListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModulisticaListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModulisticaListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
