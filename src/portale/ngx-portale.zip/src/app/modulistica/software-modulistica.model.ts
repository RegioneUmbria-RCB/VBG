import { CategoriaModulisticaItem } from './categoria-modulistica.model';

export class SoftwareModulisticaModel {
    codice: string;
    categorie: CategoriaModulisticaItem[];
    tipo: string;
}
