import { Injectable } from '@angular/core';
import { Http } from '@angular/http';


import {UrlServiziLocaliService} from '../core/services/url';
import {InfoItemModel} from './info-item.model';

@Injectable()
export class InfoService {

  infoSportello: InfoItemModel[] = [];

  constructor(private urlService: UrlServiziLocaliService, private http: Http) { }

  getList(): Promise<InfoItemModel[]> {
    return new Promise<InfoItemModel[]>( resolve => {

      if (this.infoSportello.length > 0) {
        resolve(this.infoSportello);
      }

      const url = this.urlService.url('infosportello');

      return this.http.get(url)
        .toPromise()
        .then( res => {
          const data = res.json().items as InfoItemModel[];

          this.infoSportello = data;

          resolve(this.infoSportello);
        });
    });
  }


  getById(id: number): Promise<InfoItemModel> {
    return this.getList().then( infoList => infoList.filter(i => i.id === id).shift());
  }

}
