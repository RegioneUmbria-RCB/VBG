import { Component, OnInit } from '@angular/core';
import {InfoService} from '../../info/info.service';
import {ButtonGridItem, UrlLocaliService} from '../../core';

@Component({
  selector: 'app-info-list-page',
  templateUrl: './info-list-page.component.html',
  styleUrls: ['./info-list-page.component.less']
})
export class InfoListPageComponent implements OnInit {

  infoList: ButtonGridItem[] = [];
  loading = true;

  constructor( private infoService: InfoService) { }

  ngOnInit() {
    this.infoService.getList().then( info => {
      this.infoList = info.map( i => {

        const item = new ButtonGridItem();

        item.id = i.id.toString();
        item.titolo = i.titolo;

        return item;
      });
      this.loading = false;
    });
  }

}
