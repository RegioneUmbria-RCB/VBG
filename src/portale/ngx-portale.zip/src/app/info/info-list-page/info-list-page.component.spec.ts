import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoListPageComponent } from './info-list-page.component';

describe('InfoListPageComponent', () => {
  let component: InfoListPageComponent;
  let fixture: ComponentFixture<InfoListPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InfoListPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoListPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
