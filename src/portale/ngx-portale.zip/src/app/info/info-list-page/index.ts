export * from './info-list-page.component';
