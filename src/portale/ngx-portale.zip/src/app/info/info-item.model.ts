export class InfoItemModel {
    id: number;
    titolo: string;
    descrizione: string;
}
