export class TrasparenzaListItemModel {
    
}