import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrasparenzaListComponent } from './trasparenza-list.component';

describe('TrasparenzaListComponent', () => {
  let component: TrasparenzaListComponent;
  let fixture: ComponentFixture<TrasparenzaListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrasparenzaListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrasparenzaListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
