export * from './trasparenza.service';
export * from './trasparenza-list-item.model';