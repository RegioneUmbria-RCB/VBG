import {ConfigurazioneServiziRegionaliModel} from './configurazione-servizi-regionali.model';
import {ConfigurazioneBackendModel} from './configurazione-backend.model';
import {ConfigurazioneGlobalsModel} from './configurazione-globals.model';
import {LinkModel} from '../../models';
import {BaseUrlservice} from '../url/base-url.service';
import {buildMenuUrls} from './build-menu-urls';


export class Configuration {
    constructor() {

    }

    globals: ConfigurazioneGlobalsModel;
    serviziRegionali: ConfigurazioneServiziRegionaliModel;
    backend: ConfigurazioneBackendModel;

    menu?: LinkModel[];

    deserialize (js: Configuration) {

        this.serviziRegionali = new ConfigurazioneServiziRegionaliModel (js.serviziRegionali);
        this.globals = new ConfigurazioneGlobalsModel(js.globals);
        this.backend = new ConfigurazioneBackendModel(js.backend);

        this.menu = buildMenuUrls(js.menu, new BaseUrlservice('', js.backend.alias, js.backend.software));
    }
}
