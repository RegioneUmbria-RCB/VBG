export class ConfigurazioneAreaRiservataModel {
    baseUrl: string;
    urlLogin: string;
    urlRegistrazione: string;
    urlNuovaDomanda: string;
    urlLeMiePratiche: string;
    urlArchivioPratiche: string;
    urlScadenzario: string;
    urlDownloadModelloDomanda: string;


    constructor(deser: ConfigurazioneAreaRiservataModel) {
        this.baseUrl = deser.baseUrl;
        this.urlLogin = deser.urlLogin;
        this.urlRegistrazione = deser.urlRegistrazione;
        this.urlNuovaDomanda = deser.urlNuovaDomanda;
        this.urlLeMiePratiche = deser.urlLeMiePratiche;
        this.urlArchivioPratiche = deser.urlArchivioPratiche;
        this.urlScadenzario = deser.urlScadenzario;
        this.urlDownloadModelloDomanda = deser.urlDownloadModelloDomanda;
    }

    initialize(alias: string, software: string) {
        this.baseUrl = this.ensureAliasSoftware(this.baseUrl, alias, software);

        this.urlLogin = this.ensureAliasSoftware(this.urlLogin, alias, software);
        this.urlRegistrazione = this.ensureAliasSoftware(this.urlRegistrazione, alias, software);
        this.urlNuovaDomanda = this.ensureAliasSoftware(this.urlNuovaDomanda, alias, software);
        this.urlLeMiePratiche = this.ensureAliasSoftware(this.urlLeMiePratiche, alias, software);
        this.urlArchivioPratiche = this.ensureAliasSoftware(this.urlArchivioPratiche, alias, software);
        this.urlScadenzario = this.ensureAliasSoftware(this.urlScadenzario, alias, software);
        this.urlDownloadModelloDomanda = this.ensureAliasSoftware(this.urlDownloadModelloDomanda, alias, software);
    }

    ensureAliasSoftware(path: string, alias: string, software: string) {
        if (!path) {
            return '';
        }

        path = path.replace('{alias}', alias).replace('{software}', software);

        if (!path.startsWith('http')) {
            path = this.baseUrl + path;
        }

        return path;
    }
}

