import { Injectable } from '@angular/core';
import { Http } from '@angular/http';



import 'rxjs/add/operator/toPromise';

import { Configuration } from './configuration.model';
import { ConfigurationFileUrlService } from './configuration-file-url.service';

@Injectable()
export class ConfigurationService {

  private configuration: Configuration;

  constructor(private http: Http, private configurationFileUrlService: ConfigurationFileUrlService) { }

  load(): Promise<Configuration> {

    const url = this.configurationFileUrlService.getLocalizedFileUrl();

    return this.loadInternal(url)
      .catch((error: any) => {
        console.error('Non è stato possibile caricarte il file di configurazione dall\'url ', url,
                      'verrà utilizzato il file di default, dettagli dell\'errore:', error);

        return this.loadInternal(this.configurationFileUrlService.getDefaultFileUrl());
      });
  }

  private loadInternal(url: string) {

    console.log('tentativo di caricamento del file di configurazione dall\'url', url);

    return this.http.get(url)
      .toPromise()
      .then(res => {
          const cfg = res.json() as Configuration;

          this.configuration = new Configuration();
          this.configuration.deserialize(cfg);

          console.log('Dati della configurazione caricata:', this.configuration);

          return this.configuration;
        });
  }

  private handleError(error: any): Promise<any> {
    console.error('ConfigurationService: si è verificato un errore: ', error);
    return Promise.reject(error.message || error);
  }

  getConfiguration(): Configuration {
    return this.configuration;
  }
}
