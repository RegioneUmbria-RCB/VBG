import { CanaleSocialModel } from './canale-social.model';
import {LinkModel} from '../../models';

export class ConfigurazioneGlobalsModel {
    denominazioneComune: string;
    denominazioneSportello: string;
    denominazioneRegione: string;
    linkRegione: string;
    urlQuestionario: string;
    logoComune: string;

    canaliSocial: CanaleSocialModel[];
    footerLinks: LinkModel[];

    constructor(deserialized: ConfigurazioneGlobalsModel) {

        this.denominazioneComune = deserialized.denominazioneComune;
        this.denominazioneSportello = deserialized.denominazioneSportello;
        this.denominazioneRegione = deserialized.denominazioneRegione;
        this.linkRegione = deserialized.linkRegione;
        this.urlQuestionario = deserialized.urlQuestionario;
        this.logoComune = deserialized.logoComune;

        this.canaliSocial = deserialized.canaliSocial;
        this.footerLinks = deserialized.footerLinks;
    }
}
