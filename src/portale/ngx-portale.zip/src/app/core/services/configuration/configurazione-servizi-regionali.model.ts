export class ConfigurazioneServiziRegionaliModel {

    public baseUrl: string;
    public alias: string;
    public software: string;

    constructor(desrialized: ConfigurazioneServiziRegionaliModel) {
        this.baseUrl = desrialized.baseUrl;
        this.alias = desrialized.alias;
        this.software = desrialized.software;
    }
}
