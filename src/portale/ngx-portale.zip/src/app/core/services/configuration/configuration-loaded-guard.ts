import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, ActivatedRoute, Params } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { ConfigurationService } from './configuration.service';
import { AliasSoftwareService } from '../alias-software/alias-software.service';

@Injectable()
export class ConfigurationLoadedGuard implements CanActivate {

    private configurationInitialized = false;

    constructor(private configurationService: ConfigurationService,
        private aliasSoftwareService: AliasSoftwareService,
        private router: Router) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> | boolean {

        console.log('canActivate', this.configurationInitialized);

        const primaryOutlet = 'primary';
        let alias = '';
        let software = '';

        const children = route.children.filter((c: ActivatedRouteSnapshot) => c.outlet === primaryOutlet);

        if (children.length) {
            alias = children[0].params['alias'];
            software = children[0].params['software'];
        }

        console.log('alias', alias);
        console.log('software', software);

        if (alias === '' || software === '') {

            this.router.navigate(['/404']);
            return false;
        }

        if (this.configurationInitialized) {
            return true;
        }

        this.aliasSoftwareService.setAliasSoftware(alias, software);

        return new Promise(resolve => {

            this.configurationService.load().then(() => {
                this.configurationInitialized = true;
                console.log('configurazione caricata');
                resolve(this.configurationInitialized);
            }).catch(() => {

                this.router.navigate(['/404']);

                resolve(false);
            });
        });
    }
}
