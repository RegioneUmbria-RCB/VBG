export interface CanaleSocialModel {
    tipo: string;
    link: string;
}
