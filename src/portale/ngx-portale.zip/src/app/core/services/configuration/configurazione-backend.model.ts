import { ConfigurazioneAreaRiservataModel } from './configurazione-area-riservata.model';

export class ConfigurazioneBackendModel {
    baseUrl: string;
    alias: string;
    software: string;
    urlVisura: string;

    areaRiservata: ConfigurazioneAreaRiservataModel;

    constructor(deser: ConfigurazioneBackendModel) {
        this.baseUrl = deser.baseUrl;
        this.alias = deser.alias;
        this.software = deser.software;
        this.urlVisura = deser.urlVisura;

        this.areaRiservata = new ConfigurazioneAreaRiservataModel(deser.areaRiservata);

        this.areaRiservata.initialize(this.alias, this.software);
    }
}
