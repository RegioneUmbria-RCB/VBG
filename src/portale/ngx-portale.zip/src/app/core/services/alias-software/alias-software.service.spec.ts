import { TestBed, inject } from '@angular/core/testing';

import { AliasSoftwareService } from './alias-software.service';

describe('AliasSoftwareService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AliasSoftwareService]
    });
  });

  it('should be created', inject([AliasSoftwareService], (service: AliasSoftwareService) => {
    expect(service).toBeTruthy();
  }));
});
