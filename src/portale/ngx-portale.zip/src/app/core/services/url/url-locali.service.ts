import { Injectable } from '@angular/core';
import { BaseUrlservice } from './base-url.service';
import { AliasSoftwareService } from '../alias-software';

@Injectable()
export class UrlLocaliService extends BaseUrlservice {

  constructor(aliasSoftwareService: AliasSoftwareService) {
    super('', aliasSoftwareService.getAlias(), aliasSoftwareService.getSoftware());
  }


}
