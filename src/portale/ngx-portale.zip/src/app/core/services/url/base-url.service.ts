export class BaseUrlservice {
    constructor(private baseUrl: string, private alias: string, private software: string) { }

    url(path: string, pathParts?: string[]) {

        // tslint:disable-next-line:prefer-const
        let fullParts = [
            this.alias,
            this.software
        ];

        if (pathParts) {
            Array.prototype.push.apply(fullParts, pathParts);
        }

        return this.baseUrl + path + '/' + fullParts.join('/');
    }
}
