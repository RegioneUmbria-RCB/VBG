import { Injectable } from '@angular/core';
import { BaseUrlservice } from './base-url.service';
import { ConfigurationService } from '../configuration/configuration.service';

@Injectable()
export class UrlServiziLocaliService extends BaseUrlservice {

  constructor(configurationService: ConfigurationService) {
    super(configurationService.getConfiguration().backend.baseUrl,
          configurationService.getConfiguration().backend.alias,
          configurationService.getConfiguration().backend.software);
  }

}
