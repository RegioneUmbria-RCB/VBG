export class LinkModel {
    titolo: string;
    link: string;
}
