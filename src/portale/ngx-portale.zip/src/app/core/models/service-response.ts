export class ServiceResponse<T> {
    items: T;
}
