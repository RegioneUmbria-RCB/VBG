export * from './strip-html.pipe';
