export * from './cosa-puoi-fare-card.model';
export * from './cosa-puoi-fare.component';
