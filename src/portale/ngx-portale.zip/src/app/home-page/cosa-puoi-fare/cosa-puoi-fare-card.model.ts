export class CosaPuoiFareCardModel {
    titolo: string;
    sottotitolo: string;
    link: string;
}
