import { Component, OnInit } from '@angular/core';

import { FaqService, TopFaqModel } from '../../faq';
import { UrlLocaliService } from '../../core/services/url';

@Component({
  selector: 'app-home-faq',
  templateUrl: './home-faq.component.html',
  styleUrls: ['./home-faq.component.less']
})
export class HomeFaqComponent implements OnInit {

  topFaq: TopFaqModel[] = [];
  urlDettaglioFaq: string;


  constructor(private faqService: FaqService, urlLocali: UrlLocaliService) {
    this.urlDettaglioFaq = urlLocali.url('/faq');
  }

  ngOnInit() {
    this.faqService.getTop().then(faq => this.topFaq = faq);
  }

}
