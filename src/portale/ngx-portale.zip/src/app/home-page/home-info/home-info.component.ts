import { Component, OnInit } from '@angular/core';

import {UrlLocaliService} from '../../core/services/url';
import {InfoService, InfoItemModel} from '../../info';

@Component({
  selector: 'app-home-info',
  templateUrl: './home-info.component.html',
  styleUrls: ['./home-info.component.less']
})
export class HomeInfoComponent implements OnInit {

  info1: InfoItemModel[] = [];
  info2: InfoItemModel[] = [];

  infoArray: InfoItemModel[][] = [];

  infoUrl: string;

  constructor(private infoService: InfoService, urlService: UrlLocaliService) {
    this.infoUrl = urlService.url('/info');

    this.infoArray.push([]);
    this.infoArray.push([]);
  }

  ngOnInit() {
    this.infoService.getList().then( info => {
      info.forEach( (i, idx) => {

        this.infoArray[idx % 2].push(i);
      });
    });
  }

}
