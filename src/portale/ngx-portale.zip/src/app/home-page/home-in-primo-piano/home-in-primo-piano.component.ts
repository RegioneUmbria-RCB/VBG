import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { UrlLocaliService } from '../../core/services/url';
import { InterventiLocaliService, InterventoTopModel } from '../../interventi';
import { ProcedimentiLocaliService, ProcedimentoTopModel } from '../../procedimenti';

@Component({
  selector: 'app-home-in-primo-piano',
  templateUrl: './home-in-primo-piano.component.html',
  styleUrls: ['./home-in-primo-piano.component.less']
})
export class HomeInPrimoPianoComponent implements OnInit {

  interventiTop$: Observable<InterventoTopModel[]>;
  procedimentiTop$: Observable<ProcedimentoTopModel[]>;
  urlDettagliIntervento: string;
  urlDettagliProcedimento: string;

  constructor(private interventiService: InterventiLocaliService,
    private procedimentiService: ProcedimentiLocaliService,
    urlLocaliService: UrlLocaliService) {

    this.urlDettagliIntervento = urlLocaliService.url('/interventi-locali');
    this.urlDettagliProcedimento = urlLocaliService.url('/procedimenti');
  }

  ngOnInit() {
    this.interventiTop$ = this.interventiService.getTop();
    this.procedimentiTop$ = this.procedimentiService.getTop();
  }

}
