import { Component, HostBinding, OnInit } from '@angular/core';
import {PageScrollConfig} from 'ng2-page-scroll';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent implements OnInit {


  @HostBinding('class') public cssClass = '';

  constructor() {
    PageScrollConfig.defaultDuration = 500;
  }

  ngOnInit(): void {
    // Esempio di come impostare programmaticamente
    // la classe css del contenitore root
    this.cssClass = 'portale-comunale gualdo';
  }
}
