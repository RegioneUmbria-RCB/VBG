import { Component, OnInit, OnDestroy } from '@angular/core';

import { Observable, Subscription } from 'rxjs/rx';
import 'rxjs/add/operator/skip';
import 'rxjs/add/operator/take';

import { TopNewsModel } from '../top-news.model';
import { NewsService } from '../news.service';
import { UrlLocaliService } from '../../core/services/url';



@Component({
  selector: 'app-news-list',
  templateUrl: './news-list.component.html',
  styleUrls: ['./news-list.component.less']
})
export class NewsListComponent implements OnInit, OnDestroy {

  subscription: Subscription;
  listaNews$: Observable<TopNewsModel[]>;
  dataSource$: Observable<TopNewsModel[]>;
  caricamentoCompletato = false;

  urlDettaglio: string;

  currentPage = 0;
  pageCount = 0;

  private pageSize = 10;

  constructor(private service: NewsService, urlService: UrlLocaliService) {
    this.urlDettaglio = urlService.url('/news');
  }

  updateDataSource() {
    this.caricamentoCompletato = false;

    this.dataSource$ = this.listaNews$
      .map(data => {
        const offset = this.currentPage * this.pageSize;
        return data.slice(offset, offset + this.pageSize);
      });

    this.dataSource$.subscribe(x => {
      this.caricamentoCompletato = true;
      document.body.scrollTop = 0;
    });
  }


  newsSuccessive() {
    this.currentPage--;

    if (this.currentPage < 0) {
      this.currentPage = 0;
    }

    this.updateDataSource();
  }

  newsPrecedenti() {
    this.currentPage++;

    if (this.currentPage >= this.pageCount) {
      this.currentPage = this.pageCount - 1;
    }

    this.updateDataSource();
  }


  ngOnInit() {

    this.listaNews$ = this.service.getList();

    this.subscription = this.listaNews$.subscribe(x => {
      this.caricamentoCompletato = true;
      this.pageCount = Math.floor(x.length / this.pageSize);

      if (x.length % this.pageSize > 0) {
        this.pageCount++;
      }
    });

    this.updateDataSource();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }


}
