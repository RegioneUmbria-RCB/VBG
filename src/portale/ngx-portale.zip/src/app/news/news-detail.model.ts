export class NewsDetailModel {
    id: string;
    sottotitolo: string;
    titolo: string;
    corpo: string;
    data: string;
}
