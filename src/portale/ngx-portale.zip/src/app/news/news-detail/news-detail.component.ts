import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable, Subscription } from 'rxjs/rx';

import { NewsService } from '../news.service';
import { NewsDetailModel } from '../news-detail.model';

@Component({
  selector: 'app-news-detail',
  templateUrl: './news-detail.component.html',
  styleUrls: ['./news-detail.component.less']
})
export class NewsDetailComponent implements OnInit, OnDestroy {


  caricamentoCompletato = false;
  news: NewsDetailModel;

  subs: Subscription;

  constructor(private service: NewsService, private currRoute: ActivatedRoute, private location: Location) { }

  ngOnInit() {

    this.subs = this.currRoute.params
                  .map( pars => pars['id'])
                  .flatMap(id => this.service.getById(id))
                  .subscribe( news => {
                    this.caricamentoCompletato = true;
                    this.news = news;
                  });
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  tornaIndietro() {
    this.location.back();
  }
}
