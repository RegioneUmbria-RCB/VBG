import { TestBed, inject } from '@angular/core/testing';

import { OrariEContattiService } from './orari-e-contatti.service';

describe('OrariEContattiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OrariEContattiService]
    });
  });

  it('should be created', inject([OrariEContattiService], (service: OrariEContattiService) => {
    expect(service).toBeTruthy();
  }));
});
