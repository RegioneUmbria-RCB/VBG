import {CanaleSocialModel} from '../core/services/configuration';
import {LinkModel} from '../core/models';

export interface DatiComuneModel {
    denominazioneRegione: string;
    linkRegione: string;
    denominazioneComune: string;
    denominazioneSportello: string;
    logoComune: string;

    canaliSocial: CanaleSocialModel[];

    scrivaniaVirtuale: LinkModel;

    menu: LinkModel[];

    urlQuestionario: string;

    footerLinks: LinkModel[];

    contatti: {
        indirizzo: string[];
        pec: string;
        email: string;
        telefono: string;
        fax: string;
    };
}
