import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { UrlServiziLocaliService } from '../core/services/url';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class OrariEContattiService {

  orariecontatti: any = null;

  constructor(private http: Http, private urlServiziLocaliService: UrlServiziLocaliService) { }

  get() {

    const url = this.urlServiziLocaliService.url('orariecontatti');

    if (this.orariecontatti != null) {
      return Promise.resolve(this.orariecontatti);
    }

    return this.http.get(url)
      .map(res => {
        this.orariecontatti = res.json().items;

        return this.orariecontatti;
      })
      .toPromise();
  }
}
