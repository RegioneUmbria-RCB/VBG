import { Injectable } from '@angular/core';
import { DatiComuneModel } from './dati-comune.model';
import { ConfigurationService } from '../core/services/configuration';
import { OrariEContattiService } from './orari-e-contatti.service';

@Injectable()
export class DatiComuneService {

  datiComune: DatiComuneModel = null;

  constructor(private configurationService: ConfigurationService, private orariEContattiService: OrariEContattiService) { }

  get(): Promise<DatiComuneModel> {

    return new Promise<DatiComuneModel>(resolve => {

      if (this.datiComune != null) {
        resolve(this.datiComune);
      }

      const config = this.configurationService.getConfiguration();

      const orariEContattiPromise = this.orariEContattiService.get();

      Promise.all([
        this.orariEContattiService.get()
      ])
        .then(val => {
          const orariEContatti = val[0];

          this.datiComune = {
            denominazioneRegione: config.globals.denominazioneRegione,
            linkRegione: config.globals.linkRegione,
            denominazioneComune: config.globals.denominazioneComune || orariEContatti.denominazioneComune, 
            logoComune: config.globals.logoComune || 'default.png',
            // 'Comune di Gualdo Tadino',
            // tslint:disable-next-line:max-line-length
            denominazioneSportello: config.globals.denominazioneSportello || orariEContatti.denominazioneSportello, // 'Sportello Unico per le Attività Produttive',
            canaliSocial: config.globals.canaliSocial,
            footerLinks: config.globals.footerLinks,

            menu: config.menu.map(item => {
              return {
                titolo: item.titolo,
                link: item.link
              };
            }),

            scrivaniaVirtuale:
            {
              titolo: 'Scrivania virtuale',
              link: config.backend.areaRiservata.urlLogin
            },

            urlQuestionario: config.globals.urlQuestionario,

            contatti: {
              indirizzo: [
                config.globals.denominazioneComune || orariEContatti.denominazioneComune,
                orariEContatti.indirizzoSportello
                /*
                'Comune di Gualdo Tadino',
                'Piazza Martiri della Libertà, 4',
                '06023 Gualdo Tadino (PG)'
                */
              ],

              pec: orariEContatti.supporto.pec,
              email: orariEContatti.supporto.email,
              telefono: orariEContatti.supporto.telefono,
              fax: orariEContatti.supporto.fax
            }
          };

          resolve(this.datiComune);
        });
    });

  }

}
