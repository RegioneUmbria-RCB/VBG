import { Component, OnInit } from '@angular/core';

import {DatiComuneService, DatiComuneModel} from '../../dati-comune';

@Component({
  selector: 'app-page-footer',
  templateUrl: './page-footer.component.html',
  styleUrls: ['./page-footer.component.less']
})
export class PageFooterComponent implements OnInit {

  datiComune: DatiComuneModel;
  loaded = false;

  constructor(private datiComuneService: DatiComuneService) {

  }

  ngOnInit() {
    this.datiComuneService.get()
        .then(data => {
          this.datiComune = data;
          this.loaded = true;
        });
  }

}
