import { Component, OnInit } from '@angular/core';

import { DatiComuneService, DatiComuneModel } from '../../dati-comune';

@Component({
  selector: 'app-page-header',
  templateUrl: './page-header.component.html',
  styleUrls: ['./page-header.component.less']
})
export class PageHeaderComponent implements OnInit {

  datiComune: DatiComuneModel;
  loaded = false;
  isCollapsed = true;

  constructor(private datiComuneService: DatiComuneService) {

  }

  ngOnInit() {

    this.datiComuneService.get()
      .then(data => {
        this.datiComune = data;
        this.loaded = true;
      });
  }

}
