export interface CosaPuoiFareCardModel {
    titolo: string;
    sottotitolo: string;
    link: string;
}
