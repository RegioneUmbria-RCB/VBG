import {
    HomeConfigurationModel,
    Configuration,
} from "./../core/services/configuration/configuration.model";
import { ConfigurationService } from "./../core/services/configuration/configuration.service";
import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-home-page",
    templateUrl: "./home-page.component.html",
})
export class HomePageComponent implements OnInit {
    public homeConfig: HomeConfigurationModel;
    public faqPresenti = true;
    public newsPresenti = true;
    public infoPresenti = true;

    constructor(private configurationService: ConfigurationService) { }

    ngOnInit(): void {
        const cfg = this.configurationService.getConfiguration();
        this.initializeHomeConfig(cfg);
    }

    initializeHomeConfig(cfg: Configuration): void {
        this.homeConfig = cfg.homeConfiguration;
    }
}
