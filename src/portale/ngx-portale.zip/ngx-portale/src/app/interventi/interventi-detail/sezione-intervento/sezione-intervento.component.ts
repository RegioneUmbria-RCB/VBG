import { Component, Input } from "@angular/core";

@Component({
    selector: "app-sezione-intervento",
    templateUrl: "./sezione-intervento.component.html",
    styleUrls: ["./sezione-intervento.component.less"],
})
export class SezioneInterventoComponent {
    @Input() public titolo = "titolo sezione";
    @Input() public visibileSe = true;

}
