import { EndoprocedimentoModel } from '../intervento-griglia-endo/endoprocedimento.model';

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface InterventoLocaleModel extends EndoprocedimentoModel {

}
