export interface FaseAttuativaModel {
    titolo: string;
    descrizione: string;
}
