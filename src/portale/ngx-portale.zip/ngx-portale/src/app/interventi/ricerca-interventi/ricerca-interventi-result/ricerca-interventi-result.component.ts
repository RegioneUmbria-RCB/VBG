import { Component, Input } from "@angular/core";
import { InterventoCercato } from "@interventi/services";

@Component({
    selector: "app-ricerca-interventi-result",
    templateUrl: "./ricerca-interventi-result.component.html",
})
export class RicercaInterventiResultComponent {
    @Input()
    public titolo: string;
    @Input()
    public interventi: InterventoCercato[];
    @Input()
    public mostraTitoliSezioni = true;
    @Input()
    public urlRedirect: string;
    @Input()
    public limitaRisultati = 10;


    public onClick(): void {
        console.log("click");
    }
}
