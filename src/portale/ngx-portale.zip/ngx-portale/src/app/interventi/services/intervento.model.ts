export class InterventoModel {}
