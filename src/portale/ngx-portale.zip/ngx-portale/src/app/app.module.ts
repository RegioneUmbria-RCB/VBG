import { BrowserModule } from "@angular/platform-browser";
import { NgModule, APP_INITIALIZER } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { NgxPageScrollCoreModule } from "ngx-page-scroll-core";
import { NgxPageScrollModule } from "ngx-page-scroll";
import { AppComponent } from "./app.component";
import { HomePageComponent } from "./home-page/home-page.component";
import { PageHeaderComponent, PageFooterComponent } from "./shared";
import { CosaPuoiFareComponent } from "./home-page/cosa-puoi-fare/cosa-puoi-fare.component";
import { HomeInPrimoPianoComponent } from "./home-page/home-in-primo-piano/home-in-primo-piano.component";
import { HomeNewsComponent } from "./home-page/home-news/home-news.component";
import { HomeFaqComponent } from "./home-page/home-faq/home-faq.component";
import { HomeInfoComponent } from "./home-page/home-info/home-info.component";
import { DatiComuneService } from "./dati-comune";
import { CommonModule } from "@angular/common";
import {
    ConfigurationService,
    ConfigurationFileUrlService,
    RisorseService,
} from "./core/services";
import { AliasSoftwareService } from "./core/services/alias-software";
import { PageLayoutComponent } from "./shared/page-layout/page-layout.component";
import { PageNotFoundComponent } from "./shared/page-not-found/page-not-found.component";
import {
    UrlLocaliService,
    UrlServiziLocaliService,
    UrlServiziRegionaliService,
} from "./core/services/url";
// Servizi verso il backend
import { OrariEContattiService } from "./dati-comune";
import {
    InterventiLocaliService,
    InterventiRegionaliService,
} from "./interventi";
import {
    ProcedimentiLocaliService,
    ProcedimentiRegionaliService,
    ProcedimentiServiceFactory,
} from "./procedimenti/services";
import { NewsService } from "./news";
import { FaqService } from "./faq";
import { InfoService } from "./info";
import { NormativaService } from "./normativa";
import { ModulisticaService } from "./modulistica";
import { TrasparenzaService } from "./trasparenza/trasparenza.service";

// pipes
import { StripHtmlPipe, SlugifyPipe } from "./core/pipes";
import { RicercaInterventiComponent } from "./interventi/ricerca-interventi/ricerca-interventi.component";
import { InfoListPageComponent } from "./info/info-list-page/info-list-page.component";
import { InfoDetailPageComponent } from "./info/info-detail-page/info-detail-page.component";
import { InnerPageLayoutComponent } from "./shared/inner-page-layout/inner-page-layout.component";
import { ButtonGridComponent } from "./core/components";
import { NormativaListComponent } from "./normativa/normativa-list/normativa-list.component";
import { LoaderComponent } from "./core/components/loader/loader.component";
import { ModulisticaListComponent } from "./modulistica/modulistica-list/modulistica-list.component";
import { NewsListComponent } from "./news/news-list/news-list.component";
import { InterventiSelezioneAreaComponent } from "./interventi/interventi-selezione-area/interventi-selezione-area.component";
import { InterventiLocaliComponent } from "./interventi/interventi-locali/interventi-locali.component";
import { InterventiRegionaliComponent } from "./interventi/interventi-regionali/interventi-regionali.component";
import { InterventiLocaliDetailComponent } from "./interventi/interventi-locali-detail/interventi-locali-detail.component";
import { InterventiTreeNavigatorComponent } from "./interventi/interventi-tree-navigator/interventi-tree-navigator.component";
import { InterventiRegionaliDetailComponent } from "./interventi/interventi-regionali-detail/interventi-regionali-detail.component";
import { InterventiDetailComponent } from "./interventi/interventi-detail/interventi-detail.component";
import { InterventoGrigliaEndoComponent } from "./interventi/interventi-detail/intervento-griglia-endo/intervento-griglia-endo.component";
// eslint-disable-next-line max-len
import { InterventoListaInterventiLocaliComponent } from "./interventi/interventi-detail/intervento-lista-interventi-locali/intervento-lista-interventi-locali.component";
// eslint-disable-next-line max-len
import { InterventoFasiAttuativeComponent } from "./interventi/interventi-detail/intervento-fasi-attuative/intervento-fasi-attuative.component";
import { ProcedimentiDetailBaseComponent } from "./procedimenti/procedimenti-detail-base/procedimenti-detail-base.component";
import { ProcedimentiDetailLocaliComponent } from "./procedimenti/procedimenti-detail-locali/procedimenti-detail-locali.component";
import { SezioneComponent } from "./core/components/sezione/sezione.component";
import { GrigliaOneriComponent } from "./core/components/griglia-oneri/griglia-oneri.component";
import { GrigliaModulisticaComponent } from "./core/components/griglia-modulistica/griglia-modulistica.component";
import { GrigliaNormativaComponent } from "./core/components/griglia-normativa/griglia-normativa.component";
import { NewsDetailComponent } from "./news/news-detail/news-detail.component";
import { ShareSocialComponent } from "./core/components/share-social/share-social.component";
import { FaqListComponent } from "./faq/faq-list/faq-list.component";
import { TrasparenzaListComponent } from "./trasparenza/trasparenza-list/trasparenza-list.component";
import { TrasparenzaDetailComponent } from "./trasparenza/trasparenza-detail/trasparenza-detail.component";
import { NuovaDomandaComponent } from "./shared/nuova-domanda/nuova-domanda.component";
import { PratichePresentateComponent } from "./shared/pratiche-presentate/pratiche-presentate.component";
import { ProcedimentiDetailRegionaliComponent } from "./procedimenti/procedimenti-detail-regionali/procedimenti-detail-regionali.component";
import { SezioneInterventoComponent } from "./interventi/interventi-detail/sezione-intervento/sezione-intervento.component";
import { CosaPuoiFareV2Component } from "./home-page/cosa-puoi-fare-v2/cosa-puoi-fare-v2.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { CollapseModule } from "ngx-bootstrap/collapse";
import { BsDropdownModule } from "ngx-bootstrap/dropdown";
import { PaginationModule } from "ngx-bootstrap/pagination";
import { PaginationComponent } from "./trasparenza/pagination/pagination/pagination.component";
import { TabellaTrasparenzaComponent } from "./trasparenza/trasparenza-list/tabella-trasparenza/tabella-trasparenza.component";
// import { PagerService } from './core/services/utility/pagerService.service';
// eslint-disable-next-line max-len
import { RicercaInterventiResultComponent } from "@interventi/ricerca-interventi/ricerca-interventi-result/ricerca-interventi-result.component";
// eslint-disable-next-line max-len
import { RicercaInterventiResultContainerComponent } from "@interventi/ricerca-interventi/ricerca-interventi-result-container/ricerca-interventi-result-container.component";
import { ComuniAssociatiDirective } from "./trasparenza/trasparenza-list/comuni-associati.directive";
import { AppInitService } from "./app-init.service";
import { MenuLateraleComponent } from "@interventi/interventi-detail/menu-laterale/menu-laterale.component";
import { ScrollingModule } from "@angular/cdk/scrolling";
import { AffixDirective } from "@core/directives/affix.directive";
import { ScrollSpyDirective } from "@core/directives/scroll-spy.directive";

const appRoutes: Routes = [
    {
        path: "",
        children: [
            { path: "index/:alias/:software", component: HomePageComponent },
            {
                path: "nuova-domanda/:alias/:software",
                component: NuovaDomandaComponent,
            },
            {
                path: "pratiche-presentate/:alias/:software",
                component: PratichePresentateComponent,
            },

            { path: "home/:alias/:software", component: HomePageComponent },
            { path: "info/:alias/:software", component: InfoListPageComponent },
            {
                path: "info/:alias/:software/:id",
                component: InfoDetailPageComponent,
            },
            {
                path: "normativa/:alias/:software",
                component: NormativaListComponent,
            },
            {
                path: "interventi-selezione-area/:alias/:software",
                component: InterventiSelezioneAreaComponent,
            },
            {
                path: "interventi-locali/:alias/:software",
                component: InterventiLocaliComponent,
            },
            {
                path: "interventi-locali/:alias/:software/:id",
                component: InterventiLocaliDetailComponent,
            },
            {
                path: "interventi-regionali/:alias/:software",
                component: InterventiRegionaliComponent,
            },
            {
                path: "interventi-regionali/:alias/:software/:id",
                component: InterventiRegionaliDetailComponent,
            },

            {
                path: "procedimenti/:alias/:software/:id",
                component: ProcedimentiDetailLocaliComponent,
            },
            {
                path: "procedimenti-regionali/:alias/:software/:id",
                component: ProcedimentiDetailRegionaliComponent,
            },

            {
                path: "modulistica/:alias/:software",
                component: ModulisticaListComponent,
            },
            { path: "news/:alias/:software", component: NewsListComponent },
            {
                path: "news/:alias/:software/:id",
                component: NewsDetailComponent,
            },

            { path: "faq/:alias/:software", component: FaqListComponent },
            { path: "faq/:alias/:software/:id", component: FaqListComponent },

            {
                path: "archivio-pratiche/:alias/:software",
                component: TrasparenzaListComponent,
            },
            {
                path: "archivio-pratiche/:alias/:software/:id",
                component: TrasparenzaDetailComponent,
            },
        ],
    },
    { path: "404", component: PageNotFoundComponent },
    { path: "**", redirectTo: "/404" },
];

export const initializeApp =
    (appInitService: AppInitService) => (): Promise<void> =>
        appInitService.init();

@NgModule({
    declarations: [
        ComuniAssociatiDirective,
        AffixDirective,
        ScrollSpyDirective,
        AppComponent,
        HomePageComponent,
        PageHeaderComponent,
        PageFooterComponent,
        CosaPuoiFareComponent,
        HomeInPrimoPianoComponent,
        HomeNewsComponent,
        HomeFaqComponent,
        HomeInfoComponent,
        PageLayoutComponent,
        PageNotFoundComponent,
        StripHtmlPipe,
        SlugifyPipe,
        RicercaInterventiComponent,
        RicercaInterventiResultComponent,
        RicercaInterventiResultContainerComponent,
        InfoListPageComponent,
        InnerPageLayoutComponent,
        ButtonGridComponent,
        InfoDetailPageComponent,
        NormativaListComponent,
        LoaderComponent,
        ModulisticaListComponent,
        NewsListComponent,
        InterventiSelezioneAreaComponent,
        TabellaTrasparenzaComponent,
        InterventiLocaliComponent,
        InterventiRegionaliComponent,
        InterventiLocaliDetailComponent,
        InterventiTreeNavigatorComponent,
        InterventiRegionaliDetailComponent,
        InterventiDetailComponent,
        InterventoGrigliaEndoComponent,
        InterventoListaInterventiLocaliComponent,
        InterventoFasiAttuativeComponent,
        ProcedimentiDetailBaseComponent,
        ProcedimentiDetailLocaliComponent,
        SezioneComponent,
        GrigliaOneriComponent,
        GrigliaModulisticaComponent,
        GrigliaNormativaComponent,
        NewsDetailComponent,
        ShareSocialComponent,
        FaqListComponent,
        TrasparenzaListComponent,
        TrasparenzaDetailComponent,
        NuovaDomandaComponent,
        PratichePresentateComponent,
        ProcedimentiDetailRegionaliComponent,
        SezioneInterventoComponent,
        CosaPuoiFareV2Component,
        PaginationComponent,
        MenuLateraleComponent,
    ],
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    imports: [
        BrowserModule,
        FormsModule,
        CommonModule,
        HttpClientModule,
        NgxPageScrollModule,
        ReactiveFormsModule,
        ScrollingModule,
        NgxPageScrollCoreModule.forRoot({ duration: 500 }),
        RouterModule.forRoot(
            appRoutes,
            {
                enableTracing: false,
                scrollPositionRestoration: "top",
                anchorScrolling: "enabled",
                relativeLinkResolution: "legacy",
            } // <-- debugging purposes only
            // <-- debugging purposes only
        ),
        BrowserAnimationsModule,
        CollapseModule.forRoot(),
        BsDropdownModule.forRoot(),
        PaginationModule.forRoot(),
    ],
    providers: [
        ConfigurationService,
        AliasSoftwareService,
        DatiComuneService,
        ConfigurationFileUrlService,
        UrlLocaliService,
        UrlServiziLocaliService,
        UrlServiziRegionaliService,
        OrariEContattiService,
        InterventiLocaliService,
        InterventiRegionaliService,
        ProcedimentiLocaliService,
        ProcedimentiRegionaliService,
        ProcedimentiServiceFactory,
        NewsService,
        FaqService,
        NormativaService,
        InfoService,
        ModulisticaService,
        TrasparenzaService,
        RisorseService,
        SlugifyPipe,
        AppInitService,
        {
            provide: APP_INITIALIZER,
            useFactory: initializeApp,
            deps: [AppInitService, AliasSoftwareService, ConfigurationService],
            multi: true,
        },
    ],
    bootstrap: [AppComponent],
})
export class AppModule { }
