export class FaqModel {
    id: number;
    attiva: boolean;
    visibile: boolean;
    titolo: string;
    descrizione: string;
}
