export interface FaqConCategoriaModel {
    id: number,
    titolo: string,
    descrizione: string,
    descrizioneCategoria: string,
    ordine: number
}
