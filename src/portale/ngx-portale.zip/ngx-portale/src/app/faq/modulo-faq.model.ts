import { FaqModel } from "./faq.model";

export class ModuloFaqModel {
    id: string;
    descrizione: string;
    faq: FaqModel[];
}
