export * from "./procedimenti-base.service";
export * from "./procedimenti-locali.service";
export * from "./procedimenti-regionali.service";
export * from "./procedimenti-service.factory";
export * from "./procedimento-detail.model";
export * from "./procedimento-top.model";
