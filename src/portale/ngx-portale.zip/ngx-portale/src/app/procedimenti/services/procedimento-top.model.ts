export interface ProcedimentoTopModel {
    id: number;
    descrizioneEstesa: string;
    descrizione: string;
}
