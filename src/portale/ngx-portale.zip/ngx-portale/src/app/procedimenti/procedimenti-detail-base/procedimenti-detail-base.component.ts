import {
    Component,
    Input,
    Output,
    EventEmitter,
    ViewChild,
    ViewChildren,
    QueryList,
} from "@angular/core";
import { Location } from "@angular/common";
import { ProcedimentoDetailModel } from "../services/procedimento-detail.model";
import { CdkScrollable } from "@angular/cdk/scrolling";
import { SezioneInterventoComponent } from "@interventi/interventi-detail/sezione-intervento/sezione-intervento.component";

@Component({
    selector: "app-procedimenti-detail-base",
    templateUrl: "./procedimenti-detail-base.component.html",
})
export class ProcedimentiDetailBaseComponent {
    @Input() procedimento: ProcedimentoDetailModel;
    @Input() idAttivita: string;
    @Input() endoRegionale = false;

    @Output() tornaIndietro = new EventEmitter<string>();
    @Output() download = new EventEmitter<string>();

    @ViewChild(CdkScrollable) scrollContainer: CdkScrollable;

    public sezioneAttiva = "";
    public listaSezioni = new Array<string>();

    @ViewChildren(SezioneInterventoComponent) set sezioneInterventoComponent(
        value: QueryList<SezioneInterventoComponent>
    ) {
        // Evita l'errore 'Expression has changed...'
        setTimeout(() => {
            this.listaSezioni = value
                .toArray()
                .filter((x) => x.visibileSe)
                .map((x) => x.titolo);
        }, 0);
    }

    constructor(private location: Location) { }


    onDownload($event: string): void {
        this.download.emit($event);
    }

    tornaAdAttivita(): void {
        this.location.back();
    }

    onSectionChange(newSectionId: string): void {
        this.sezioneAttiva = newSectionId;
    }
}
