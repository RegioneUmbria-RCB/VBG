import { ModulisticaItemModel } from "./modulistica-item.model";

export class CategoriaModulisticaItem {
    nome: string;
    codice: string;
    modulistica: ModulisticaItemModel[];
}
