import { Component } from "@angular/core";
import { environment } from "../../../environments/environment";

@Component({
    selector: "app-page-not-found",
    templateUrl: "./page-not-found.component.html",
})
export class PageNotFoundComponent {
    isProduction: boolean = environment.production;
}
