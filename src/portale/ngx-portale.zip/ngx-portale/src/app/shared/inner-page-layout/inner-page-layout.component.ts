import { Component, Input } from "@angular/core";

@Component({
    selector: "app-inner-page-layout",
    templateUrl: "./inner-page-layout.component.html",
})
export class InnerPageLayoutComponent {
    @Input() isLoading = false;
}
