import { Component, OnInit } from "@angular/core";
import { DatiComuneService, DatiComuneModel } from "../../dati-comune";
import { ThemesPathBuilder } from "../../core/services/themes/themes-builder";
import { RisorseService } from "@core/services";

@Component({
    selector: "app-page-header",
    templateUrl: "./page-header.component.html",
})
export class PageHeaderComponent implements OnInit {
    pathLogoComune: string;
    datiComune: DatiComuneModel;
    loaded = false;
    isCollapsed = true;
    passaALinks = false;
    linkComune = false;
    nascondiTitoloPagina = false;

    constructor(
        private datiComuneService: DatiComuneService,
        private risorseService: RisorseService
    ) { }

    ngOnInit(): void {
        this.datiComuneService.get().subscribe((data) => {
            this.datiComune = data;
            this.pathLogoComune = new ThemesPathBuilder(
                data.themeLocation
            ).getLogoComune();
            this.loaded = true;
            if (this.datiComune.passaALinks) {
                this.passaALinks = true;
            }
            if (this.datiComune.linkComune) {
                this.linkComune = true;
            }
        });

        this.nascondiTitoloPagina =
            this.risorseService.getRisorsa(
                "header.nascondi-titolo-applicazione",
                "false"
            ) === "true";

        console.log("this.nascondiTitoloPagina", this.nascondiTitoloPagina);
    }
}
