import { Component, OnInit } from "@angular/core";
import { ConfigurationService } from "../../core";

@Component({
    selector: "app-pratiche-presentate",
    templateUrl: "./pratiche-presentate.component.html",
})
export class PratichePresentateComponent implements OnInit {
    constructor(private arConfig: ConfigurationService) { }

    ngOnInit(): void {
        console.log(
            this.arConfig.getConfiguration().backend.areaRiservata
                .urlLeMiePratiche
        );
        document.location.replace(
            this.arConfig.getConfiguration().backend.areaRiservata
                .urlLeMiePratiche
        );
    }
}
