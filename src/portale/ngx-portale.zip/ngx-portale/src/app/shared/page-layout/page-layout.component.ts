import { Component, OnInit } from "@angular/core";
import { Router, NavigationEnd } from "@angular/router";

@Component({
    selector: "app-page-layout",
    templateUrl: "./page-layout.component.html",
})
export class PageLayoutComponent implements OnInit {
    constructor(private router: Router) { }

    ngOnInit(): void {
        this.router.events.subscribe((evt) => {
            if (!(evt instanceof NavigationEnd)) {
                return;
            }
            document.body.scrollTop = 0;
        });
    }
}
