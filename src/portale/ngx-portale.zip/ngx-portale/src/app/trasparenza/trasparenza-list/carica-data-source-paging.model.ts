export class CaricaDataSourcePagingModel {
    constructor(public pagina: number, public elementiPerPagina: number) {}
}
