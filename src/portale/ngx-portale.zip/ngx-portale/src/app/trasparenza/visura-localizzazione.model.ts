export interface VisuraLocalizzazioneModel {
    nazione: string,
    comune: string,
    indirizzo: string,
    datiCatastali: string
}

