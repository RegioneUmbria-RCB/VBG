export class IndirizzoBrevePraticaModel {
    indirizzo: string;
    comune: string;
}
