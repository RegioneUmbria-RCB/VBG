export interface VisuraDatoGeneraleModel {
    nome: string,
    valore: string
}
