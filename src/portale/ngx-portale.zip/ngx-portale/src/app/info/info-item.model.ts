export class InfoItemModel {
    id: number;
    titolo: string;
    descrizione: string;
}

export class InfoItemModelWrapper {
    items: InfoItemModel[];
}
