export interface IStatoIstanzaDTO {
    id: string;
    stato: string;
}

export class StatoIstanzaDTO implements IStatoIstanzaDTO {
    id: string;
    stato: string;
}