export * from "./alias-software.service";
