export class UrlParams {
    constructor(
        public baseUrl: string,
        public alias: string,
        public software: string
    ) {}
}
