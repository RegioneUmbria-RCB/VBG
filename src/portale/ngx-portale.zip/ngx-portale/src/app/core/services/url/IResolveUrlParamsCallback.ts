import { UrlParams } from "./url-params";

export type IResolveUrlParamsCallback = () => UrlParams;
