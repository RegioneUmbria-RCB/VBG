export interface OnereModel {
    causale: string;
    importo: string;
}
