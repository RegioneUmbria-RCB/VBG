export interface NormativaModel {
    descrizione: string;
    tipologia: string;
    codiceOggetto: number;
    link: string;
}
