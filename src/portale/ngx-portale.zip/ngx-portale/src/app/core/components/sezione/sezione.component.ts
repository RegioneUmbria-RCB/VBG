import { Component, Input } from "@angular/core";

@Component({
    selector: "app-sezione",
    templateUrl: "./sezione.component.html",
})
export class SezioneComponent {
    @Input() titolo: string;
    @Input() corpo: string;

}
