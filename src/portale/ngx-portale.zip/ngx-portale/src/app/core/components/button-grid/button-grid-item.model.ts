export class ButtonGridItem {
    id: string;
    titolo: string;
    sottotitolo?: string;
    sopratitolo?: string;
    link?: string;
}
