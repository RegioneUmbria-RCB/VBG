export class TopNewsModel {
    id: string;
    titolo: string;
    sottotitolo: string;
    data: string;
}
