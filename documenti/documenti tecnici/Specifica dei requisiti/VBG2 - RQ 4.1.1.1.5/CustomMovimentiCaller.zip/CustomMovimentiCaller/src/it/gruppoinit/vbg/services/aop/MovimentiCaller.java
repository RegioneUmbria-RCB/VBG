package it.gruppoinit.vbg.services.aop;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import it.gruppoinit.sigepro.backoffice.domain.Movimenti;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.JoinPoint;

public class MovimentiCaller {

    public MovimentiCaller() {

	System.out.println("Inizializzazione della classe " + getClass().getCanonicalName());
    }

    public void doCustomCall(JoinPoint jp) {

	String metodo = jp.getSignature().getName();
	Object[] args = jp.getArgs();
	String codiceMovimento = "";
	for (Object object : args) {
	    if (object instanceof Movimenti) {
		if (((Movimenti) object).getId().getCodice() != null) {
		    codiceMovimento = ((Movimenti) object).getId().toString();
		}
	    }
	}
	String output = "Intercettato il metodo " + metodo;
	if (StringUtils.isNotBlank(codiceMovimento)) {
	    output += " del movimento: " + codiceMovimento;
	}
	try {
	    inviaMail("riccardo.bocci@gruppoinit.it", "riccardo.bocci@gruppoinit.it", output, output);
	} catch (MessagingException e) {
	    e.printStackTrace();
	}
    }

    public static void inviaMail(String dest, String mitt, String oggetto, String testoEmail) throws MessagingException {

	// Creazione di una mail session
	Properties props = new Properties();
	props.setProperty("mail.transport.protocol", "smtp");
	props.setProperty("mail.host", "avalon");
	props.put("mail.smtp.auth", "true");
	Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {

	    protected PasswordAuthentication getPasswordAuthentication() {

		return new PasswordAuthentication("riccardob", "");
	    }
	});
	// Creazione del messaggio da inviare
	MimeMessage message = new MimeMessage(session);
	String riferimento = "20110824@init.gruppoinit.it";
	message.addHeader("Message-ID", riferimento);
	message.setSubject(oggetto);
	message.setText(testoEmail);
	// Aggiunta degli indirizzi del mittente e del destinatario
	InternetAddress fromAddress = new InternetAddress(mitt);
	InternetAddress toAddress = new InternetAddress(dest);
	message.setFrom(fromAddress);
	message.setRecipient(Message.RecipientType.TO, toAddress);
	// Invio del messaggio
	Transport.send(message);
    }
}
