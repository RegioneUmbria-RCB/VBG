
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.0  Built on : May 17, 2011 (04:21:18 IST)
 */

        
            package it.init.sigepro.rte;
        
            /**
            *  ExtensionMapper class
            */
            @SuppressWarnings({"unchecked","unused"})
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "statoIter_type1".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.StatoIter_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "PersonaFisicaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.PersonaFisicaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "AllegatiType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.AllegatiType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "TipoCampoDinamicoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.TipoCampoDinamicoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "XsdTypesVersion".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.XsdTypesVersion.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "ProprietaCampoDinamicoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.ProprietaCampoDinamicoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "OneriPagamentiType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.OneriPagamentiType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "EstremiAttoEstesoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.EstremiAttoEstesoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "TipoAttivitaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.TipoAttivitaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "ProcuraType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.ProcuraType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "RichiedenteType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.RichiedenteType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "DocumentiType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.DocumentiType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "InterventoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.InterventoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "SchedaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.SchedaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "StatoPraticaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.StatoPraticaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "ValoreParametroType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.ValoreParametroType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "TipoDocumentoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.TipoDocumentoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "SportelloType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.SportelloType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "OneriType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.OneriType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "PersonaGiuridicaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.PersonaGiuridicaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "ComuneType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.ComuneType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "AllegatoBinarioType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.AllegatoBinarioType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "lunghezza_type1".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.Lunghezza_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "FiltriUtenteType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.FiltriUtenteType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "CampoStaticoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.CampoStaticoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "FiltriPraticaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.FiltriPraticaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "RiferimentiAttivitaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.RiferimentiAttivitaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "CausaleOnereType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.CausaleOnereType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "RegistroREAType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.RegistroREAType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "tipoCatasto_type1".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.TipoCatasto_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "LocalizzazioneNelComuneType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.LocalizzazioneNelComuneType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "SiglaProvinciaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.SiglaProvinciaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "CampoSchedaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.CampoSchedaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "DettaglioPraticaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.DettaglioPraticaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "ValoriCampoCheckboxType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.ValoriCampoCheckboxType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "statoIter_type1".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.StatoIter_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte".equals(namespaceURI) &&
                  "XsdNlaVersion".equals(typeName)){
                   
                            return  it.init.sigepro.rte.XsdNlaVersion.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "AnagrafeType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.AnagrafeType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "DettaglioPraticaVisuraType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.DettaglioPraticaVisuraType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "DettaglioAttivitaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.DettaglioAttivitaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "rifCatastaliTipoCatasto_type1".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.RifCatastaliTipoCatasto_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "EstremiAttoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.EstremiAttoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "DettaglioPraticaBreveType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.DettaglioPraticaBreveType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "ProcedimentoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.ProcedimentoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "RiferimentoCatastaleType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.RiferimentoCatastaleType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "LocalizzazioneType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.LocalizzazioneType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "CampoDinamicoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.CampoDinamicoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "riga_type1".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.Riga_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "modalita_type1".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.Modalita_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "AltriSoggettiType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.AltriSoggettiType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "cifreDecimali_type1".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.CifreDecimali_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "ErroreType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.ErroreType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "RuoloType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.RuoloType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "IscrizioneRegistroType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.IscrizioneRegistroType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "ParametroType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.ParametroType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "colonna_type1".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.Colonna_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "PosizioneCampoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.PosizioneCampoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "TipoCampoStaticoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.TipoCampoStaticoType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "OneriScadenzeType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.OneriScadenzeType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "RiferimentiPraticaType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.RiferimentiPraticaType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://sigepro.init.it/rte/types".equals(namespaceURI) &&
                  "RiferimentiAllegatoType".equals(typeName)){
                   
                            return  it.init.sigepro.rte.types.RiferimentiAllegatoType.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    