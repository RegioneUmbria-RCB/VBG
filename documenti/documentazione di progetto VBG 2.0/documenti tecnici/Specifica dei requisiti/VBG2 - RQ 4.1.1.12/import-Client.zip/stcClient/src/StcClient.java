import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import it.init.sigepro.rte.definitions.StcServiceStub;
import it.init.sigepro.rte.definitions.StcServiceStub.ErroreType;
import it.init.sigepro.rte.definitions.StcServiceStub.InserimentoPraticaRequest;
import it.init.sigepro.rte.definitions.StcServiceStub.InserimentoPraticaResponse;

public class StcClient {

    private String url;
    private String username;
    private String password;

    public StcClient(String url, String username, String password) {

	this.url = url;
	this.username = username;
	this.password = password;
    }

    public String login() {

	System.out.println("Login...");
	boolean success = false;
	String token = "";
	try {
	    StcServiceStub stub = new StcServiceStub(url);
	    StcServiceStub.LoginRequest loginReq = new StcServiceStub.LoginRequest();
	    loginReq.setUsername(username);
	    loginReq.setPassword(password);
	    StcServiceStub.LoginResponse loginResp = stub.login(loginReq);
	    success = loginResp.getResult();
	    System.out.println("Login result: " + success);
	    if (success) {
		token = loginResp.getToken();
		System.out.println("Login token:  " + token);
	    }
	} catch (AxisFault e) {
	    System.err.println("Login Error: " + e.getMessage());
	} catch (RemoteException e) {
	    System.err.println("Login Error: " + e.getMessage());
	}
	return token;
    }

    public InserimentoPraticaResponse inserisciPratica(InserimentoPraticaRequest inserimentoPraticaRequest) {

	System.out.println("InserisciPratica...");
	InserimentoPraticaResponse inserimentoPraticaResponse = null;
	try {
	    StcServiceStub stub = new StcServiceStub(url);
	    inserimentoPraticaResponse = stub.inserimentoPratica(inserimentoPraticaRequest);
	    if (inserimentoPraticaResponse.isDettaglioPraticaSpecified()) {
		System.out.println("id pratica: " + inserimentoPraticaResponse.getDettaglioPratica().getIdPratica());
		System.out.println("numero pratica: " + inserimentoPraticaResponse.getDettaglioPratica().getNumeroPratica());
	    }
	    if (inserimentoPraticaResponse.isDettaglioErroreSpecified()) {
		for (ErroreType err : inserimentoPraticaResponse.getDettaglioErrore()) {
		    System.err.println("Error: " + err.getNumeroErrore() + " - " + err.getDescrizione());
		}
	    }
	} catch (AxisFault e) {
	    System.err.println("InserisciPratica Error: " + e.getMessage());
	} catch (RemoteException e) {
	    System.err.println("InserisciPratica Error: " + e.getMessage());
	}
	return inserimentoPraticaResponse;
    }
}
