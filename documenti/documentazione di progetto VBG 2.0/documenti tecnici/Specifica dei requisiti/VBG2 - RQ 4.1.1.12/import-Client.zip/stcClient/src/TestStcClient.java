import it.init.sigepro.rte.definitions.StcServiceStub;

import java.rmi.RemoteException;
import java.util.Date;

public class TestStcClient {

    /**
     * @param args
     * @throws RemoteException
     */
    public static void main(String[] args) throws RemoteException {

	//dati login stc
	String username = "BACKOFFICE";
	String password = "123";
	String url = "http://localhost:9090/stc/services";
	//dati nla mitt
	String idente_mitt = "TEST";
	String isportello_mitt = "TEST";
	String idnodo_mitt = "1000";
	//dati nla dest
	String idente_dest = "E256";
	String isportello_dest = "CE";
	String idnodo_dest = "400";
	//dati pratica mitt
	String idpratica = "1";
	String numpratica = "1/2001";
	Date datapratica = new Date();
	String oggettopratica = "COLLAUDO";
	String nomeRich = "MARCO";
	String cognomeRich = "MANDO";
	String cfRich = "MRCMND74H26D786O";
	//STC Client
	StcClient stcClient = new StcClient(url, username, password);
	//STC Login
	String token = stcClient.login();
	if (!"".equals(token)) {
	    //STC InserisciPratica
	    StcServiceStub.InserimentoPraticaRequest inserimentoPraticaRequest = new StcServiceStub.InserimentoPraticaRequest();
	    inserimentoPraticaRequest.setToken(token);
	    StcServiceStub.SportelloType sportelloMitt = new StcServiceStub.SportelloType();
	    sportelloMitt.setIdEnte(idente_mitt);
	    sportelloMitt.setIdNodo(idnodo_mitt);
	    sportelloMitt.setIdSportello(isportello_mitt);
	    inserimentoPraticaRequest.setSportelloMittente(sportelloMitt);
	    StcServiceStub.SportelloType sportelloDest = new StcServiceStub.SportelloType();
	    sportelloDest.setIdEnte(idente_dest);
	    sportelloDest.setIdNodo(idnodo_dest);
	    sportelloDest.setIdSportello(isportello_dest);
	    inserimentoPraticaRequest.setSportelloDestinatario(sportelloDest);
	    StcServiceStub.DettaglioPraticaType dettaglioPraticaType = new StcServiceStub.DettaglioPraticaType();
	    dettaglioPraticaType.setIdPratica(idpratica);
	    dettaglioPraticaType.setNumeroPratica(numpratica);
	    dettaglioPraticaType.setDataPratica(datapratica);
	    dettaglioPraticaType.setOggetto(oggettopratica);
	    StcServiceStub.RichiedenteType richiedente = new StcServiceStub.RichiedenteType();
	    StcServiceStub.PersonaFisicaType personaFisicaType = new StcServiceStub.PersonaFisicaType();
	    personaFisicaType.setNome(nomeRich);
	    personaFisicaType.setCognome(cognomeRich);
	    personaFisicaType.setCodiceFiscale(cfRich);
	    richiedente.setAnagrafica(personaFisicaType);
	    dettaglioPraticaType.setRichiedente(richiedente);
	    inserimentoPraticaRequest.setDettaglioPratica(dettaglioPraticaType);
	    stcClient.inserisciPratica(inserimentoPraticaRequest);
	}
    }
}
