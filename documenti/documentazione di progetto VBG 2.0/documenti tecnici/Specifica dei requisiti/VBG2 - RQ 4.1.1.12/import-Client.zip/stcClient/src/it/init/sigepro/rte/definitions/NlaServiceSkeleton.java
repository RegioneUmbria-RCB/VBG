/**
 * NlaServiceSkeleton.java
 * 
 * This file was auto-generated from WSDL by the Apache Axis2 version: 1.6.0 Built on : May 17, 2011 (04:19:43 IST)
 */
package it.init.sigepro.rte.definitions;

/**
 * NlaServiceSkeleton java skeleton for the axisService
 */
public class NlaServiceSkeleton {

    /**
     * Auto generated method signature
     * 
     * @param inserimentoPraticaNLARequest
     * @return inserimentoPraticaNLAResponse
     */
    public it.init.sigepro.rte.InserimentoPraticaNLAResponse inserimentoPraticaNLA(
	    it.init.sigepro.rte.InserimentoPraticaNLARequest inserimentoPraticaNLARequest) {

	//TODO : fill this with the necessary business logic
	throw new java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#inserimentoPraticaNLA");
    }

    /**
     * Auto generated method signature
     * 
     * @param richiestaPraticheListaNLARequest
     * @return richiestaPraticheListaNLAResponse
     */
    public it.init.sigepro.rte.RichiestaPraticheListaNLAResponse richiestaPraticheListaNLA(
	    it.init.sigepro.rte.RichiestaPraticheListaNLARequest richiestaPraticheListaNLARequest) {

	//TODO : fill this with the necessary business logic
	throw new java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#richiestaPraticheListaNLA");
    }

    /**
     * Auto generated method signature
     * 
     * @param allegatoBinarioNLARequest
     * @return allegatoBinarioNLAResponse
     */
    public it.init.sigepro.rte.AllegatoBinarioNLAResponse allegatoBinarioNLA(it.init.sigepro.rte.AllegatoBinarioNLARequest allegatoBinarioNLARequest) {

	//TODO : fill this with the necessary business logic
	throw new java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#allegatoBinarioNLA");
    }

    /**
     * Auto generated method signature
     * 
     * @param testNLARequest
     * @return testNLAResponse
     */
    public it.init.sigepro.rte.TestNLAResponse testNLA(it.init.sigepro.rte.TestNLARequest testNLARequest) {

	it.init.sigepro.rte.TestNLAResponse testNLAResponse = new it.init.sigepro.rte.TestNLAResponse();
	testNLAResponse.setNlaXsdVersion(it.init.sigepro.rte.XsdNlaVersion.V_1_0);
	testNLAResponse.setTypesXsdVersion(it.init.sigepro.rte.types.XsdTypesVersion.V_1_0);
	return testNLAResponse;
    }

    /**
     * Auto generated method signature
     * 
     * @param richiestaPraticaNLARequest
     * @return richiestaPraticaNLAResponse
     */
    public it.init.sigepro.rte.RichiestaPraticaNLAResponse richiestaPraticaNLA(
	    it.init.sigepro.rte.RichiestaPraticaNLARequest richiestaPraticaNLARequest) {

	//TODO : fill this with the necessary business logic
	throw new java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#richiestaPraticaNLA");
    }

    /**
     * Auto generated method signature
     * 
     * @param inserimentoAttivitaNLARequest
     * @return inserimentoAttivitaNLAResponse
     */
    public it.init.sigepro.rte.InserimentoAttivitaNLAResponse inserimentoAttivitaNLA(
	    it.init.sigepro.rte.InserimentoAttivitaNLARequest inserimentoAttivitaNLARequest) {

	//TODO : fill this with the necessary business logic
	throw new java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#inserimentoAttivitaNLA");
    }
}
