password keystore.jks: password
password truststore.jks: password